package app.edgevolume

import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private class Preset(
        val name: String, val shape: Int, val mode: Int, val c1: Int, val c2: Int,
        val glow: Int, val thick: Int, val effect: Int, val fill: Int, val enter: Int,
        val opacity: Int = 100
    )

    private val presets = listOf(
        Preset("Cyan", 0, 0, 0xFF00E5FF.toInt(), 0xFFFF4081.toInt(), 24, 4, 0, 1, 0),
        Preset("Sunset", 0, 2, 0xFFFF9100.toInt(), 0xFFFF4081.toInt(), 32, 5, 1, 1, 0),
        Preset("Aurora", 0, 2, 0xFF00E676.toInt(), 0xFF7C4DFF.toInt(), 36, 5, 2, 1, 1),
        Preset("Meter", 1, 4, 0xFF76FF03.toInt(), 0xFFFF1744.toInt(), 16, 5, 0, 0, 0),
        Preset("Neon dot", 2, 0, 0xFFFF4081.toInt(), 0xFF7C4DFF.toInt(), 30, 4, 3, 2, 0),
        Preset("Ambient", 3, 0, 0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt(), 44, 3, 1, 1, 0, 70)
    )

    private lateinit var p: Prefs
    private lateinit var col: LinearLayout
    private var density = 1f
    private val handler = Handler(Looper.getMainLooper())
    private val previewRun = Runnable { VolumeService.instance?.preview() }
    private val statusRefreshers = ArrayList<() -> Unit>()

    private fun dp(i: Int) = (i * density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        p = Prefs(this)
        density = resources.displayMetrics.density

        col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(32))
        }
        setContentView(ScrollView(this).apply {
            addView(col)
            setOnApplyWindowInsetsListener { v, ins ->
                val i = ins.getInsets(WindowInsets.Type.systemBars())
                v.setPadding(i.left, i.top, i.right, i.bottom)
                ins
            }
        })

        col.addView(TextView(this).apply {
            text = "Edge Volume Light"
            textSize = 24f
        })

        // ---------------------------------------------------------------- setup
        section("Setup")
        permRow(
            "Accessibility service (required)",
            "Turn on \"Edge Volume Light\". If it is greyed out: App info > ⋮ menu > Allow restricted settings.",
            { VolumeService.instance != null }
        ) { Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS) }
        permRow(
            "Modify system settings (brightness)",
            "Needed only if you want to control brightness.",
            { Settings.System.canWrite(this) }
        ) { Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")) }
        permRow(
            "Do Not Disturb access (silent mode)",
            "Needed only to switch to Silent. Ring and Vibrate work without it.",
            { getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted }
        ) { Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS) }

        col.addView(Switch(this).apply {
            text = "Replace system volume panel"
            isChecked = p.replacePanel
            setPadding(0, dp(16), 0, dp(4))
            setOnCheckedChangeListener { _, on ->
                p.replacePanel = on
                changed()
            }
        })

        col.addView(Button(this).apply {
            text = "Test"
            setOnClickListener {
                val s = VolumeService.instance
                if (s == null) toast("Turn on the accessibility service first") else s.preview()
            }
        })

        // ---------------------------------------------------------------- presets
        section("Presets")
        val prow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        presets.forEach { pr ->
            prow.addView(Button(this).apply {
                text = pr.name
                isAllCaps = false
                setOnClickListener { applyPreset(pr) }
            })
        }
        col.addView(HorizontalScrollView(this).apply { addView(prow) })

        // ---------------------------------------------------------------- controls
        section("What the volume keys control")
        col.addView(TextView(this).apply { text = "Tap the panel's lower button to cycle through the checked ones." })
        VolumeService.NAMES.forEachIndexed { i, n ->
            col.addView(CheckBox(this).apply {
                text = "${VolumeService.ICONS[i]}  $n"
                isChecked = ((p.targetMask shr i) and 1) == 1
                setOnCheckedChangeListener { _, on ->
                    p.targetMask = if (on) p.targetMask or (1 shl i) else p.targetMask and (1 shl i).inv()
                    changed()
                }
            })
        }

        section("Control panel")
        col.addView(Switch(this).apply {
            text = "Keep dim handle visible"
            isChecked = p.panelIdle
            setOnCheckedChangeListener { _, on ->
                p.panelIdle = on
                changed()
            }
        })
        slider("Height on screen", "%", 0, 85, p.panelY) { p.panelY = it }
        slider("Stays open for", "ms", 1000, 8000, p.panelDuration) { p.panelDuration = it }

        // ---------------------------------------------------------------- look
        section("Edge light")
        label("Side")
        val rg = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        listOf("Left", "Right", "Both").forEachIndexed { i, t ->
            rg.addView(RadioButton(this).apply {
                id = 100 + i
                text = t
            })
        }
        rg.check(100 + p.side)
        rg.setOnCheckedChangeListener { _, id ->
            p.side = id - 100
            changed()
        }
        col.addView(rg)

        choice("Shape", listOf("Bar", "Segments", "Dot", "Full edge"), { p.shape }) { p.shape = it }
        choice(
            "Color mode",
            listOf("Solid", "Per control (media, ring...)", "Gradient", "Rainbow", "Green to red"),
            { p.colorMode }
        ) { p.colorMode = it }

        colorRow("Main color (solid / gradient start)", { p.color }) { p.color = it }
        colorRow("Gradient end color", { p.color2 }) { p.color2 = it }
        VolumeService.NAMES.forEachIndexed { i, n ->
            colorRow("Color for $n", { p.targetColor(i) }) { p.setTargetColor(i, it) }
        }

        slider("Thickness", "dp", 2, 16, p.thickness) { p.thickness = it }
        slider("Glow", "dp", 0, 64, p.glow) { p.glow = it }
        slider("Opacity", "%", 10, 100, p.opacity) { p.opacity = it }
        slider("Visible for", "ms", 500, 4000, p.duration) { p.duration = it }

        // ---------------------------------------------------------------- animation
        section("Animation")
        choice("Appear / disappear", listOf("Fade", "Slide in from edge", "None"), { p.enterAnim }) { p.enterAnim = it }
        choice("Level change", listOf("Instant", "Smooth", "Bouncy"), { p.fillAnim }) { p.fillAnim = it }
        choice("Effect", listOf("None", "Pulse glow", "Shimmer", "Flash on change"), { p.effect }) { p.effect = it }
    }

    override fun onResume() {
        super.onResume()
        statusRefreshers.forEach { it() }
    }

    // -------------------------------------------------------------------- helpers

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    /** Apply changes live and show a demo shortly after the user stops fiddling. */
    private fun changed() {
        VolumeService.instance?.onPrefsChanged()
        handler.removeCallbacks(previewRun)
        handler.postDelayed(previewRun, 400)
    }

    private fun applyPreset(pr: Preset) {
        p.shape = pr.shape
        p.colorMode = pr.mode
        p.color = pr.c1
        p.color2 = pr.c2
        p.glow = pr.glow
        p.thickness = pr.thick
        p.effect = pr.effect
        p.fillAnim = pr.fill
        p.enterAnim = pr.enter
        p.opacity = pr.opacity
        VolumeService.instance?.onPrefsChanged()
        handler.removeCallbacks(previewRun)
        handler.postDelayed(previewRun, 400)
        recreate()
    }

    private fun section(t: String) {
        col.addView(TextView(this).apply {
            text = t
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(28), 0, dp(6))
        })
    }

    private fun label(t: String) {
        col.addView(TextView(this).apply {
            text = t
            setPadding(0, dp(12), 0, dp(2))
        })
    }

    private fun permRow(title: String, desc: String, ok: () -> Boolean, intent: () -> Intent) {
        val t = TextView(this).apply { setPadding(0, dp(8), 0, 0) }
        val b = Button(this).apply {
            text = "Open settings"
            setOnClickListener {
                try {
                    startActivity(intent())
                } catch (e: Exception) {
                    toast("Could not open that settings page")
                }
            }
        }
        val refresh = {
            val g = ok()
            t.text = (if (g) "✅ " else "❌ ") + title + "\n" + desc
            b.visibility = if (g) View.GONE else View.VISIBLE
        }
        statusRefreshers.add(refresh)
        col.addView(t)
        col.addView(b)
        refresh()
    }

    private fun choice(name: String, opts: List<String>, get: () -> Int, set: (Int) -> Unit) {
        label(name)
        col.addView(Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, opts)
            setSelection(get(), false)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    if (pos != get()) {
                        set(pos)
                        changed()
                    }
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        })
    }

    private fun slider(
        name: String, unit: String, min: Int, max: Int, init: Int, onSet: (Int) -> Unit
    ) {
        val t = TextView(this).apply {
            text = "$name: $init $unit"
            setPadding(0, dp(12), 0, 0)
        }
        val s = SeekBar(this).apply {
            this.max = max - min
            progress = init - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, v: Int, fromUser: Boolean) {
                    val x = v + min
                    t.text = "$name: $x $unit"
                    if (fromUser) {
                        onSet(x)
                        changed()
                    }
                }

                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        }
        col.addView(t)
        col.addView(s)
    }

    private fun colorRow(name: String, get: () -> Int, set: (Int) -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, dp(6))
        }
        val sw = View(this)
        fun paintSwatch() {
            sw.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(get())
                setStroke(dp(2), 0xFF888888.toInt())
            }
        }
        paintSwatch()
        val openPicker = View.OnClickListener {
            pickColor(get()) {
                set(it)
                paintSwatch()
                changed()
            }
        }
        sw.setOnClickListener(openPicker)
        row.setOnClickListener(openPicker)
        row.addView(
            TextView(this).apply { text = name },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        row.addView(sw, LinearLayout.LayoutParams(dp(40), dp(40)))
        col.addView(row)
    }

    private fun pickColor(initial: Int, onPick: (Int) -> Unit) {
        val hsv = FloatArray(3)
        Color.colorToHSV(initial, hsv)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), 0)
        }
        val preview = View(this).apply { setBackgroundColor(Color.HSVToColor(hsv)) }
        box.addView(preview, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48)))

        fun bar(name: String, maxV: Int, initV: Int, setter: (Int) -> Unit) {
            box.addView(TextView(this).apply {
                text = name
                setPadding(0, dp(8), 0, 0)
            })
            box.addView(SeekBar(this).apply {
                this.max = maxV
                progress = initV
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar, v: Int, fromUser: Boolean) {
                        setter(v)
                        preview.setBackgroundColor(Color.HSVToColor(hsv))
                    }

                    override fun onStartTrackingTouch(sb: SeekBar) {}
                    override fun onStopTrackingTouch(sb: SeekBar) {}
                })
            })
        }
        bar("Hue", 360, hsv[0].toInt()) { hsv[0] = it.toFloat() }
        bar("Saturation", 100, (hsv[1] * 100).toInt()) { hsv[1] = it / 100f }
        bar("Brightness", 100, (hsv[2] * 100).toInt()) { hsv[2] = it / 100f }

        AlertDialog.Builder(this)
            .setTitle("Pick a color")
            .setView(box)
            .setPositiveButton("OK") { _, _ -> onPick(Color.HSVToColor(hsv)) }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
