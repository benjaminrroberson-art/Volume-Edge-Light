package app.edgevolume

import android.app.Activity
import android.app.AlertDialog
import android.Manifest
import android.app.NotificationManager
import android.content.pm.PackageManager
import android.widget.EditText
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private class Preset(
        val name: String, val shape: Int, val mode: Int, val c1: Int, val c2: Int,
        val glow: Int, val thick: Int, val effect: Int, val fill: Int, val enter: Int,
        val opacity: Int = 100, val pattern: Int = 0
    )

    private val presets = listOf(
        Preset("Cyan", 0, 0, 0xFF00E5FF.toInt(), 0xFFFF4081.toInt(), 24, 4, 0, 1, 0),
        Preset("Sunset", 0, 2, 0xFFFF9100.toInt(), 0xFFFF4081.toInt(), 32, 5, 1, 1, 0),
        Preset("Aurora", 0, 2, 0xFF00E676.toInt(), 0xFF7C4DFF.toInt(), 36, 5, 2, 1, 1),
        Preset("Meter", 1, 4, 0xFF76FF03.toInt(), 0xFFFF1744.toInt(), 16, 5, 0, 0, 0),
        Preset("Neon dot", 2, 0, 0xFFFF4081.toInt(), 0xFF7C4DFF.toInt(), 30, 4, 3, 2, 0),
        Preset("Ambient", 3, 0, 0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt(), 44, 3, 1, 1, 0, 70),
        Preset("Mirror", 0, 2, 0xFFFF9100.toInt(), 0xFFFF4081.toInt(), 30, 5, 0, 1, 0, 100, 1),
        Preset("Wrap", 0, 2, 0xFF00E5FF.toInt(), 0xFF7C4DFF.toInt(), 30, 4, 2, 1, 0, 100, 2),
        Preset("Orbit", 0, 3, 0xFF00E5FF.toInt(), 0xFFFF4081.toInt(), 20, 4, 0, 1, 0, 100, 3),
        Preset("Swell", 0, 4, 0xFF76FF03.toInt(), 0xFFFF1744.toInt(), 40, 4, 0, 1, 0, 100, 4)
    )

    private lateinit var p: Prefs
    private lateinit var col: LinearLayout
    private var density = 1f
    private val handler = Handler(Looper.getMainLooper())
    private val previewRun = Runnable { VolumeService.instance?.preview() }
    private val statusRefreshers = ArrayList<() -> Unit>()

    private fun dp(i: Int) = (i * density).toInt()

    // keep scroll positions across recreateKeep() so lists don't snap back
    private var vScroll: ScrollView? = null
    private val hScrolls = ArrayList<HorizontalScrollView>()
    private object Keep { var y = 0; var xs = ArrayList<Int>(); var on = false }

    private fun hscroll(inner: View): HorizontalScrollView {
        val h = HorizontalScrollView(this).apply { addView(inner) }
        hScrolls.add(h)
        return h
    }

    private fun recreateKeep() {
        Keep.y = vScroll?.scrollY ?: 0
        Keep.xs = ArrayList(hScrolls.map { it.scrollX })
        Keep.on = true
        recreate()
    }

    private fun restoreScroll() {
        if (!Keep.on) return
        Keep.on = false
        val y = Keep.y
        val xs = Keep.xs
        vScroll?.post {
            vScroll?.scrollTo(0, y)
            hScrolls.forEachIndexed { i, h -> if (i < xs.size) h.scrollTo(xs[i], 0) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        p = Prefs(this)
        density = resources.displayMetrics.density

        col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(32))
        }
        if (Build.VERSION.SDK_INT >= 33) {
            onBackInvokedDispatcher.registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT) {
                if (Nav.page != "home") go("home") else finish()
            }
        }
        vScroll = ScrollView(this).apply {
            addView(col)
            setOnApplyWindowInsetsListener { v, ins ->
                val i = ins.getInsets(WindowInsets.Type.systemBars())
                v.setPadding(i.left, i.top, i.right, i.bottom)
                ins
            }
        }
        setContentView(vScroll)

        col.addView(TextView(this).apply {
            text = "Edge Volume Light"
            textSize = 24f
        })

        if (Nav.page == "home") {
            buildHome()
        } else {
            val pg = PAGES.firstOrNull { it.first == Nav.page }
            subHeader(pg?.second ?: "Settings")
            skip = true
            when (Nav.page) {
                "presets" -> build_presets()
                "keys" -> build_keys()
                "gear" -> build_gear()
                "menu" -> build_menu()
                "look" -> build_look()
                "anim" -> build_anim()
                "audio" -> build_audio()
                "music" -> build_music()
                else -> build_presets()
            }
        }
        restoreScroll()
    }
    private val PAGES = listOf(
        Triple("presets", "Presets", "Ready-made and saved looks"),
        Triple("keys", "Volume keys", "Hold delay and repeat speed"),
        Triple("gear", "Gear button", "Icon, size, position, visibility"),
        Triple("menu", "Gear menu", "Which controls it offers"),
        Triple("look", "Edge light", "Pattern, shape, colors, glow"),
        Triple("anim", "Animation", "Motion, effects, appear/disappear"),
        Triple("audio", "Audio output animation", "Headphone connect/disconnect"),
        Triple("music", "Music reaction", "Light reacts to the music")
    )

    private object Nav { var page = "home"; var homeY = 0 }
    private var skip = false

    private fun go(pg: String) {
        if (Nav.page == "home") Nav.homeY = vScroll?.scrollY ?: 0
        Nav.page = pg
        if (pg == "home") {
            Keep.y = Nav.homeY
            Keep.xs = ArrayList()
            Keep.on = true
        } else {
            Keep.on = false
        }
        recreate()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (Nav.page != "home") go("home") else super.onBackPressed()
    }

    private fun subHeader(title: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        row.addView(Button(this).apply {
            text = "‹ Back"
            isAllCaps = false
            setOnClickListener { go("home") }
        })
        row.addView(TextView(this).apply {
            text = title
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(12), 0, 0, 0)
        })
        col.addView(row)
    }

    private fun buildHome() {
        // ---------------------------------------------------------------- setup
        section("Setup")
        permRow(
            "Accessibility service (required)",
            "Turn on \"Edge Volume Light\". If it is greyed out: App info > ⋮ menu > Allow restricted settings.",
            { VolumeService.instance != null }
        ) { Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS) }
        permRow(
            "Modify system settings (brightness)",
            "Needed only if you want to control brightness.",
            { Settings.System.canWrite(this) }
        ) { Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")) }
        permRow(
            "Do Not Disturb access (silent mode)",
            "Needed only to switch to Silent. Ring and Vibrate work without it.",
            { getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted }
        ) { Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS) }



        section("Main switches")
        col.addView(Switch(this).apply {
            text = "Replace system volume panel"
            isChecked = p.replacePanel
            setPadding(0, dp(16), 0, dp(4))
            setOnCheckedChangeListener { _, on ->
                p.replacePanel = on
                changed()
            }
        })

        col.addView(Switch(this).apply {
            text = "Edge light reacts to music"
            isChecked = p.musicEnabled
            setPadding(0, dp(4), 0, dp(4))
            setOnCheckedChangeListener { _, on ->
                p.musicEnabled = on
                if (on && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7)
                }
                VolumeService.instance?.onPrefsChanged()
            }
        })

        col.addView(Switch(this).apply {
            text = "Animate on output change"
            isChecked = p.connectOn
            setPadding(0, dp(8), 0, dp(4))
            setOnCheckedChangeListener { _, on -> p.connectOn = on; VolumeService.instance?.onPrefsChanged() }
        })

        col.addView(Button(this).apply {
            text = "Test"
            setOnClickListener {
                val s = VolumeService.instance
                if (s == null) toast("Turn on the accessibility service first") else s.preview()
            }
        })

        section("Customize")
        PAGES.forEach { pg ->
            col.addView(Button(this).apply {
                text = pg.second + "  ›\n" + pg.third
                isAllCaps = false
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                setOnClickListener { go(pg.first) }
            })
        }
    }

    private fun build_presets() {
        // ---------------------------------------------------------------- presets
        section("Presets")
        val prow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        presets.forEach { pr ->
            prow.addView(Button(this).apply {
                text = pr.name
                isAllCaps = false
                setOnClickListener { applyPreset(pr) }
            })
        }
        col.addView(hscroll(prow))

        col.addView(Button(this).apply {
            text = "Save current look as preset…"
            isAllCaps = false
            setOnClickListener { savePresetDialog() }
        })
        val mine = p.savedPresetNames()
        if (mine.isNotEmpty()) {
            label("Your presets (tap to load, long-press to delete)")
            val urow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            mine.forEach { nm ->
                urow.addView(Button(this).apply {
                    text = "★ $nm"
                    isAllCaps = false
                    setOnClickListener {
                        p.loadPreset(nm)
                        VolumeService.instance?.onPrefsChanged()
                        handler.removeCallbacks(previewRun)
                        handler.postDelayed(previewRun, 400)
                        recreateKeep()
                    }
                    setOnLongClickListener {
                        AlertDialog.Builder(this@MainActivity)
                            .setTitle("Delete preset \"$nm\"?")
                            .setPositiveButton("Delete") { _, _ ->
                                p.deletePreset(nm)
                                recreateKeep()
                            }
                            .setNegativeButton("Cancel", null)
                            .show()
                        true
                    }
                })
            }
            col.addView(hscroll(urow))
        }

    }

    private fun build_keys() {
        // ---------------------------------------------------------------- keys
        section("Volume keys")
        slider("Hold delay before repeating", "ms", 150, 800, p.holdDelay) { p.holdDelay = it }
        slider("Repeat interval (lower = faster)", "ms", 30, 300, p.holdInterval) { p.holdInterval = it }
        col.addView(Switch(this).apply {
            text = "Speed up the longer you hold"
            isChecked = p.holdAccel
            setPadding(0, dp(12), 0, dp(4))
            setOnCheckedChangeListener { _, on ->
                p.holdAccel = on
                changed()
            }
        })

    }

    private fun build_gear() {
        section("Gear button")
        choice(
            "Icon",
            listOf("Gear", "Dots", "Sliders", "Bars", "Ring", "Chevron"),
            { p.gearIcon }
        ) { p.gearIcon = it }
        choice(
            "Background",
            listOf("Dark disc", "None (icon only)", "Filled with color", "Outline only"),
            { p.gearBgStyle }
        ) { p.gearBgStyle = it }
        choice("Shape", listOf("Circle", "Rounded square"), { p.gearShape }) { p.gearShape = it }
        colorRow("Disc and menu background color", { p.gearBgColor }) { p.gearBgColor = it }
        choice("Icon color", listOf("Same as edge light", "Custom"), { p.gearColorMode }) { p.gearColorMode = it }
        colorRow("Custom icon color", { p.gearColor }) { p.gearColor = it }
        slider("Size", "dp", 28, 72, p.gearSize) { p.gearSize = it }
        slider("Opacity", "%", 20, 100, p.gearOpacity) { p.gearOpacity = it }
        slider("Distance from screen edge", "dp", 0, 48, p.gearInset) { p.gearInset = it }
        slider("Height on screen", "%", 0, 80, p.panelY) { p.panelY = it }
        slider("Gear stays visible for", "ms", 1000, 8000, p.panelDuration) { p.panelDuration = it }
        col.addView(Switch(this).apply {
            text = "Keep a dim gear visible all the time"
            isChecked = p.panelIdle
            setPadding(0, dp(12), 0, dp(4))
            setOnCheckedChangeListener { _, on ->
                p.panelIdle = on
                changed()
            }
        })
        slider("Dim opacity when parked", "%", 10, 80, p.gearIdle) { p.gearIdle = it }

    }

    private fun build_menu() {
        section("Gear menu")
        col.addView(TextView(this).apply {
            text = "Choose which controls the menu offers (the keys control one at a time):"
        })
        VolumeService.NAMES.forEachIndexed { i, n ->
            col.addView(CheckBox(this).apply {
                text = n
                isChecked = ((p.targetMask shr i) and 1) == 1
                setOnCheckedChangeListener { _, on ->
                    p.targetMask = if (on) p.targetMask or (1 shl i) else p.targetMask and (1 shl i).inv()
                    changed()
                }
            })
        }
        col.addView(Switch(this).apply {
            text = "Tap outside the menu to close it"
            isChecked = p.closeOutside
            setPadding(0, dp(12), 0, dp(4))
            setOnCheckedChangeListener { _, on ->
                p.closeOutside = on
                changed()
            }
        })
        slider("Menu stays open for", "ms", 3000, 30000, p.panelOpenDuration) { p.panelOpenDuration = it }
        col.addView(Switch(this).apply {
            text = "Keep menu open until I close it"
            isChecked = p.panelOpenForever
            setPadding(0, dp(12), 0, dp(4))
            setOnCheckedChangeListener { _, on ->
                p.panelOpenForever = on
                changed()
            }
        })

    }

    private fun build_look() {
        // ---------------------------------------------------------------- look
        section("Edge light")
        choice(
            "Pattern",
            listOf(
                "Bottom to top",
                "Center outward (up and down)",
                "Center outward, wrapping around the phone",
                "Clockwise loop around the phone",
                "Swell (thicker and brighter)"
            ),
            { p.pattern }
        ) { p.pattern = it }
        choice(
            "Shape (first two patterns)",
            listOf("Bar", "Segments", "Dot", "Full edge"),
            { p.shape }
        ) { p.shape = it }

        label("Side (not used by the loop)")
        val rg = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        listOf("Left", "Right", "Both").forEachIndexed { i, t ->
            rg.addView(RadioButton(this).apply {
                id = 100 + i
                text = t
            })
        }
        rg.check(100 + p.side)
        rg.setOnCheckedChangeListener { _, id ->
            p.side = id - 100
            changed()
        }
        col.addView(rg)

        choice(
            "Color mode",
            listOf("Solid", "Per control (media, ring...)", "Gradient", "Rainbow", "Green to red"),
            { p.colorMode }
        ) { p.colorMode = it }

        colorRow("Main color (solid / gradient start)", { p.color }) { p.color = it }
        colorRow("Gradient end color", { p.color2 }) { p.color2 = it }
        VolumeService.NAMES.forEachIndexed { i, n ->
            colorRow("Color for $n", { p.targetColor(i) }) { p.setTargetColor(i, it) }
        }

        slider("Thickness", "dp", 2, 16, p.thickness) { p.thickness = it }
        slider("Glow", "dp", 0, 64, p.glow) { p.glow = it }
        slider("Opacity", "%", 10, 100, p.opacity) { p.opacity = it }
        slider("Screen corner radius (wrap and loop)", "dp", 0, 70, p.corner) { p.corner = it }
        slider("Visible for", "ms", 500, 4000, p.duration) { p.duration = it }

    }

    private fun build_anim() {
        // ---------------------------------------------------------------- animation
        section("Animation")
        choice("Motion of the level", listOf("Instant", "Smooth glide", "Springy"), { p.fillAnim }) { p.fillAnim = it }
        slider("Glide time (longer = smoother)", "ms", 60, 1000, p.smoothMs) { p.smoothMs = it }
        choice("Appear / disappear", listOf("Fade", "Slide in from edge", "None", "Grow from zero (retracts on exit)"), { p.enterAnim }) { p.enterAnim = it }
        choice(
            "Effect",
            listOf(
                "None", "Pulse glow", "Shimmer", "Flash on change",
                "Breathe (glow size)", "Comet", "Wave", "Color cycle"
            ),
            { p.effect }
        ) { p.effect = it }
        slider("Effect intensity", "%", 5, 100, p.effectIntensity) { p.effectIntensity = it }
        slider("Effect speed", "%", 25, 300, p.effectSpeed) { p.effectSpeed = it }
        col.addView(TextView(this).apply {
            text = "Shimmer, Comet and Wave need the Bar shape. Color cycle needs a colored (not white) light."
            textSize = 12f
            setPadding(0, dp(6), 0, 0)
        })

    }

    private fun build_audio() {
        // ---------------------------------------------------------------- audio output
        section("Audio output animation")
        col.addView(TextView(this).apply {
            text = "A quick edge animation when headphones or another audio output connect or disconnect. Uses the same edge (left / right / both) as the edge light."
            textSize = 12f
        })
        col.addView(Switch(this).apply {
            text = "Bluetooth devices"
            isChecked = p.connectBt
            setOnCheckedChangeListener { _, on -> p.connectBt = on }
        })
        col.addView(Switch(this).apply {
            text = "Wired / USB headphones"
            isChecked = p.connectWired
            setOnCheckedChangeListener { _, on -> p.connectWired = on }
        })
        col.addView(Switch(this).apply {
            text = "Also animate when disconnected"
            isChecked = p.connectDisc
            setOnCheckedChangeListener { _, on -> p.connectDisc = on }
        })
        choice(
            "Animation style",
            listOf("Sweep along the edge", "Soft pulse", "Quick flash", "Comet"),
            { p.connectStyle }
        ) { p.connectStyle = it; nextConnect = true }
        choice(
            "Colors",
            listOf("Match edge light colors", "Custom colors"),
            { p.connectColorMode }
        ) { p.connectColorMode = it; nextConnect = true }
        colorRow("Custom: connected color", { p.connectColor }) { p.connectColor = it; nextConnect = true }
        colorRow("Custom: disconnected color", { p.connectColorOff }) { p.connectColorOff = it; nextConnect = true }
        slider("Duration", " ms", 400, 3000, p.connectDuration) { p.connectDuration = it; nextConnect = true }
        slider("Thickness", "dp", 2, 24, p.connectThick) { p.connectThick = it; nextConnect = true }
        slider("Glow", "dp", 10, 120, p.connectGlow) { p.connectGlow = it; nextConnect = true }
        slider("Brightness", "%", 20, 100, p.connectBright) { p.connectBright = it; nextConnect = true }
        col.addView(Button(this).apply {
            text = "Test connect animation"
            isAllCaps = false
            setOnClickListener {
                val sv = VolumeService.instance
                if (sv == null) toast("Turn on the accessibility service first") else sv.previewConnect(true)
            }
        })
        col.addView(Button(this).apply {
            text = "Test disconnect animation"
            isAllCaps = false
            setOnClickListener {
                val sv = VolumeService.instance
                if (sv == null) toast("Turn on the accessibility service first") else sv.previewConnect(false)
            }
        })

    }

    private fun build_music() {
        // ---------------------------------------------------------------- music
        section("Music reaction")
        col.addView(TextView(this).apply {
            text = "The light stays at your media volume level and sticks out with the music. " +
                "The audio is only analysed live, never recorded or stored. " +
                "Uses the microphone permission (Android requires it for audio analysis)."
            textSize = 12f
        })
        permRow(
            "Audio permission",
            "Needed to analyse the music.",
            { checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED }
        ) { Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")) }
        choice(
            "Which apps trigger it",
            listOf("Any app playing music", "Only the apps I pick", "All apps except the ones I pick"),
            { p.musicAppMode }
        ) { p.musicAppMode = it; VolumeService.instance?.onPrefsChanged() }
        permRow(
            "Notification access (only for picking apps)",
            "Lets the app see which app is playing. No notifications are read.",
            { listenerEnabled() }
        ) { Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) }
        col.addView(Button(this).apply {
            text = "Choose apps…"
            isAllCaps = false
            setOnClickListener { chooseApps() }
        })
        choice(
            "Visualizer style",
            listOf("Spectrum bars", "Jagged / random bars", "Waveform ridge", "Beat spikes"),
            { p.musicStyle }
        ) { p.musicStyle = it; VolumeService.instance?.onPrefsChanged() }
        slider("Number of bars", "", 6, 48, p.musicBars) { p.musicBars = it }
        slider("How far it sticks out", "dp", 10, 140, p.musicDepth) { p.musicDepth = it }
        slider("Sensitivity", "%", 30, 250, p.musicSens) { p.musicSens = it }
        slider("Visualizer opacity", "%", 20, 100, p.musicOpacity) { p.musicOpacity = it }
        col.addView(Switch(this).apply {
            text = "Also show on the lock screen"
            isChecked = p.musicLock
            setPadding(0, dp(8), 0, dp(4))
            setOnCheckedChangeListener { _, on ->
                p.musicLock = on
                VolumeService.instance?.onPrefsChanged()
            }
        })
        col.addView(TextView(this).apply {
            text = "Music styles use the Bottom-up or Center-out patterns and the Bar shape."
            textSize = 12f
        })
        val status = TextView(this).apply { setPadding(0, dp(8), 0, 0) }
        statusRefreshers.add { status.text = VolumeService.musicStatus }
        col.addView(status)
        col.addView(Button(this).apply {
            text = "Test music light (8 s demo)"
            isAllCaps = false
            setOnClickListener {
                val sv = VolumeService.instance
                if (sv == null) toast("Turn on the accessibility service first") else sv.previewMusic()
                handler.postDelayed({ status.text = VolumeService.musicStatus }, 1500)
            }
        })
        col.addView(Button(this).apply {
            text = "Refresh status"
            isAllCaps = false
            setOnClickListener { status.text = VolumeService.musicStatus }
        })
    }


    private fun listenerEnabled(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return flat.contains(packageName)
    }

    private fun savePresetDialog() {
        val et = EditText(this).apply { hint = "Preset name"; setSingleLine() }
        AlertDialog.Builder(this)
            .setTitle("Save current look")
            .setView(et)
            .setPositiveButton("Save") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isEmpty()) {
                    toast("Give it a name")
                } else {
                    p.savePreset(n)
                    toast("Saved \"$n\"")
                    recreateKeep()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun chooseApps() {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinctBy { it.first }
            .filter { it.first != packageName }
            .sortedBy { it.second.lowercase() }
        val picked = p.musicApps.split(',').filter { it.isNotEmpty() }.toMutableSet()
        val checked = BooleanArray(apps.size) { apps[it].first in picked }
        AlertDialog.Builder(this)
            .setTitle("Choose apps")
            .setMultiChoiceItems(apps.map { it.second }.toTypedArray(), checked) { _, i, on ->
                checked[i] = on
            }
            .setPositiveButton("OK") { _, _ ->
                val keep = picked.filter { pk -> apps.none { it.first == pk } }.toMutableSet()
                apps.forEachIndexed { i, a -> if (checked[i]) keep.add(a.first) }
                p.musicApps = keep.joinToString(",")
                VolumeService.instance?.onPrefsChanged()
                toast("${keep.size} app(s) selected")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        statusRefreshers.forEach { it() }
    }

    // -------------------------------------------------------------------- helpers

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    /** Apply changes live and show a demo shortly after the user stops fiddling. */
    private var nextConnect = false
    private val connectRun = Runnable { VolumeService.instance?.previewConnect(true) }

    private fun changed() {
        if (nextConnect) {
            nextConnect = false
            handler.removeCallbacks(connectRun)
            handler.postDelayed(connectRun, 400)
            return
        }
        VolumeService.instance?.onPrefsChanged()
        handler.removeCallbacks(previewRun)
        handler.postDelayed(previewRun, 400)
    }

    private fun applyPreset(pr: Preset) {
        p.shape = pr.shape
        p.colorMode = pr.mode
        p.color = pr.c1
        p.color2 = pr.c2
        p.glow = pr.glow
        p.thickness = pr.thick
        p.effect = pr.effect
        p.fillAnim = pr.fill
        p.enterAnim = pr.enter
        p.opacity = pr.opacity
        p.pattern = pr.pattern
        VolumeService.instance?.onPrefsChanged()
        handler.removeCallbacks(previewRun)
        handler.postDelayed(previewRun, 400)
        recreateKeep()
    }

    private fun section(t: String) {
        if (skip) { skip = false; return }
        col.addView(TextView(this).apply {
            text = t
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(28), 0, dp(6))
        })
    }

    private fun label(t: String) {
        col.addView(TextView(this).apply {
            text = t
            setPadding(0, dp(12), 0, dp(2))
        })
    }

    private fun permRow(title: String, desc: String, ok: () -> Boolean, intent: () -> Intent) {
        val t = TextView(this).apply { setPadding(0, dp(8), 0, 0) }
        val b = Button(this).apply {
            text = "Open settings"
            setOnClickListener {
                try {
                    startActivity(intent())
                } catch (e: Exception) {
                    toast("Could not open that settings page")
                }
            }
        }
        val refresh = {
            val g = ok()
            t.text = (if (g) "✅ " else "❌ ") + title + "\n" + desc
            b.visibility = if (g) View.GONE else View.VISIBLE
        }
        statusRefreshers.add(refresh)
        col.addView(t)
        col.addView(b)
        refresh()
    }

    private fun choice(name: String, opts: List<String>, get: () -> Int, set: (Int) -> Unit) {
        label(name)
        col.addView(Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, opts)
            setSelection(get(), false)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    if (pos != get()) {
                        set(pos)
                        changed()
                    }
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        })
    }

    private fun slider(
        name: String, unit: String, min: Int, max: Int, init: Int, onSet: (Int) -> Unit
    ) {
        val t = TextView(this).apply {
            text = "$name: $init $unit"
            setPadding(0, dp(12), 0, 0)
        }
        val s = SeekBar(this).apply {
            this.max = max - min
            progress = init - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, v: Int, fromUser: Boolean) {
                    val x = v + min
                    t.text = "$name: $x $unit"
                    if (fromUser) {
                        onSet(x)
                        changed()
                    }
                }

                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        }
        col.addView(t)
        col.addView(s)
    }

    private fun colorRow(name: String, get: () -> Int, set: (Int) -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, dp(6))
        }
        val sw = View(this)
        fun paintSwatch() {
            sw.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(get())
                setStroke(dp(2), 0xFF888888.toInt())
            }
        }
        paintSwatch()
        val openPicker = View.OnClickListener {
            pickColor(get()) { picked ->
                set(picked)
                paintSwatch()
                changed()
            }
        }
        sw.setOnClickListener(openPicker)
        row.setOnClickListener(openPicker)
        row.addView(
            TextView(this).apply { text = name },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        row.addView(sw, LinearLayout.LayoutParams(dp(40), dp(40)))
        col.addView(row)
    }

    private fun pickColor(initial: Int, onPick: (Int) -> Unit) {
        val hsv = FloatArray(3)
        Color.colorToHSV(initial, hsv)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), 0)
        }
        val preview = View(this).apply { setBackgroundColor(Color.HSVToColor(hsv)) }
        box.addView(preview, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48)))

        fun bar(name: String, maxV: Int, initV: Int, setter: (Int) -> Unit) {
            box.addView(TextView(this).apply {
                text = name
                setPadding(0, dp(8), 0, 0)
            })
            box.addView(SeekBar(this).apply {
                this.max = maxV
                progress = initV
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar, v: Int, fromUser: Boolean) {
                        setter(v)
                        preview.setBackgroundColor(Color.HSVToColor(hsv))
                    }

                    override fun onStartTrackingTouch(sb: SeekBar) {}
                    override fun onStopTrackingTouch(sb: SeekBar) {}
                })
            })
        }
        bar("Hue", 360, hsv[0].toInt()) { hsv[0] = it.toFloat() }
        bar("Saturation", 100, (hsv[1] * 100).toInt()) { hsv[1] = it / 100f }
        bar("Brightness", 100, (hsv[2] * 100).toInt()) { hsv[2] = it / 100f }

        AlertDialog.Builder(this)
            .setTitle("Pick a color")
            .setView(box)
            .setPositiveButton("OK") { _, _ -> onPick(Color.HSVToColor(hsv)) }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
