package app.edgevolume

import android.content.Context
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("edge", Context.MODE_PRIVATE)

    private inner class I(private val k: String, private val d: Int) : ReadWriteProperty<Any?, Int> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Int = sp.getInt(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) {
            sp.edit().putInt(k, value).apply()
        }
    }

    private inner class B(private val k: String, private val d: Boolean) : ReadWriteProperty<Any?, Boolean> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Boolean = sp.getBoolean(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) {
            sp.edit().putBoolean(k, value).apply()
        }
    }

    /** Consume volume keys and hide the system panel */
    var replacePanel by B("replace", true)

    /** Currently controlled thing: 0 media, 1 ring, 2 alarm, 3 call, 4 brightness */
    var target by I("target", 0)

    /** Bitmask of targets included when cycling */
    var targetMask by I("mask", 31)

    // ---- edge light look ----
    /** 0 left, 1 right, 2 both */
    var side by I("side", 1)

    /** 0 bar, 1 segments, 2 dot, 3 full edge */
    var shape by I("shape", 0)

    /** 0 solid, 1 per-target, 2 gradient, 3 rainbow, 4 green-to-red */
    var colorMode by I("cmode", 0)
    var color by I("color", 0xFF00E5FF.toInt())
    var color2 by I("color2", 0xFFFF4081.toInt())
    var thickness by I("thickness", 4)   // dp
    var glow by I("glow", 24)            // dp
    var opacity by I("opacity", 100)     // percent
    var duration by I("duration", 1500)  // ms

    // ---- animation ----
    /** 0 fade, 1 slide, 2 none */
    var enterAnim by I("enter", 0)

    /** 0 instant, 1 smooth, 2 bouncy */
    var fillAnim by I("fill", 1)

    /** 0 none, 1 pulse, 2 shimmer, 3 flash on change */
    var effect by I("effect", 0)

    // ---- control panel ----
    var panelIdle by B("panelIdle", false)
    var panelY by I("panelY", 35)             // percent of screen height
    var panelDuration by I("panelDur", 3500)  // ms

    private val defaultTc = intArrayOf(
        0xFF00E5FF.toInt(), 0xFFFF9100.toInt(), 0xFFFF1744.toInt(),
        0xFF76FF03.toInt(), 0xFFFFEA00.toInt()
    )

    fun targetColor(i: Int): Int = sp.getInt("tc$i", defaultTc[i])
    fun setTargetColor(i: Int, c: Int) {
        sp.edit().putInt("tc$i", c).apply()
    }
}
