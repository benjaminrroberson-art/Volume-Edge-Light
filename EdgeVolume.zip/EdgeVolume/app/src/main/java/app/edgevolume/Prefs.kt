package app.edgevolume

import android.content.Context
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty
import org.json.JSONObject

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("edge", Context.MODE_PRIVATE)

    private inner class I(private val k: String, private val d: Int) : ReadWriteProperty<Any?, Int> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Int = sp.getInt(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) {
            sp.edit().putInt(k, value).apply()
        }
    }

    private inner class B(private val k: String, private val d: Boolean) : ReadWriteProperty<Any?, Boolean> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Boolean = sp.getBoolean(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) {
            sp.edit().putBoolean(k, value).apply()
        }
    }

    private inner class S(private val k: String, private val d: String) : ReadWriteProperty<Any?, String> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): String = sp.getString(k, d) ?: d
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: String) {
            sp.edit().putString(k, value).apply()
        }
    }

    private val ps = ctx.applicationContext.getSharedPreferences("presets", Context.MODE_PRIVATE)

    /** Consume volume keys and hide the system panel */
    var replacePanel by B("replace", true)

    /** Currently controlled thing: 0 media, 1 ring, 2 alarm, 3 call, 4 brightness */
    var target by I("target", 0)

    /** Bitmask of targets shown in the panel */
    var targetMask by I("mask", 31)

    // ---- holding a volume key ----
    var holdDelay by I("holdDelay", 350)     // ms before repeating starts
    var holdInterval by I("holdInt", 80)     // ms between repeats (lower = faster)
    var holdAccel by B("holdAccel", true)    // speed up the longer it is held

    // ---- edge light look ----
    /** 0 bottom-up, 1 center-out, 2 center-out wrapping around phone, 3 clockwise loop, 4 swell */
    var pattern by I("pattern", 0)

    /** 0 left, 1 right, 2 both */
    var side by I("side", 1)

    /** 0 bar, 1 segments, 2 dot, 3 full edge (patterns 0 and 1 only) */
    var shape by I("shape", 0)

    /** 0 solid, 1 per-target, 2 gradient, 3 rainbow, 4 green-to-red */
    var colorMode by I("cmode", 0)
    var color by I("color", 0xFF00E5FF.toInt())
    var color2 by I("color2", 0xFFFF4081.toInt())
    var thickness by I("thickness", 4)   // dp
    var glow by I("glow", 24)            // dp
    var opacity by I("opacity", 100)     // percent
    var duration by I("duration", 1500)  // ms
    var corner by I("corner", 34)        // dp, screen corner radius for wrap/loop

    // ---- animation ----
    /** 0 fade, 1 slide, 2 none */
    var enterAnim by I("enter", 0)

    /** 0 instant, 1 smooth, 2 springy */
    var fillAnim by I("fill", 1)

    /** how long the level takes to glide, ms */
    var smoothMs by I("smoothMs", 280)

    /** 0 none, 1 pulse, 2 shimmer, 3 flash on change, 4 breathe, 5 comet, 6 wave, 7 color cycle */
    var effect by I("effect", 0)
    var effectIntensity by I("fxInt", 80)   // percent
    var effectSpeed by I("fxSpeed", 100)    // percent

    // ---- gear panel ----
    var panelIdle by B("panelIdle", false)
    var panelY by I("panelY", 35)             // percent of screen height
    var panelDuration by I("panelDur", 3500)  // ms

    // ---- gear button look ----
    /** 0 gear, 1 dots, 2 sliders, 3 bars, 4 ring, 5 chevron */
    var gearIcon by I("gearIcon", 0)
    var gearSize by I("gearSize", 44)          // dp
    var gearOpacity by I("gearOpacity", 100)   // percent
    var gearIdle by I("gearIdle", 35)          // percent, when parked as a dim handle

    /** 0 dark disc, 1 none, 2 filled with color, 3 outline only */
    var gearBgStyle by I("gearBg", 0)
    var gearBgColor by I("gearBgColor", 0xFF141A22.toInt())

    /** 0 circle, 1 rounded square */
    var gearShape by I("gearShape", 0)

    /** 0 same as edge light, 1 custom */
    var gearColorMode by I("gearCMode", 0)
    var gearColor by I("gearColor", 0xFFFFFFFF.toInt())
    var gearInset by I("gearInset", 12)        // dp from the screen edge

    // ---- gear menu (the card that opens) ----
    var panelOpenDuration by I("panelOpenDur", 10000)  // ms
    var panelOpenForever by B("panelOpenForever", false)
    var closeOutside by B("closeOutside", true)

    // ---- music reaction ----
    var musicEnabled by B("musicOn", false)

    /** 0 spectrum, 1 jagged, 2 waveform, 3 beat spikes */
    var musicStyle by I("musicStyle", 0)
    var musicBars by I("musicBars", 24)
    var musicDepth by I("musicDepth", 48)       // dp the visualizer sticks out
    var musicSens by I("musicSens", 100)        // percent
    var musicOpacity by I("musicOpacity", 85)   // percent

    /** 0 any app, 1 only picked apps, 2 every app except picked */
    var musicAppMode by I("musicAppMode", 0)
    var musicApps by S("musicApps", "")         // comma-separated package names
    var musicLock by B("musicLock", false)      // also show on lock screen

    // ---- saved presets (the "look": edge light, animation, gear, music style) ----
    private val presetKeys: List<String> = listOf(
        "pattern", "side", "shape", "cmode", "color", "color2", "thickness", "glow", "opacity",
        "duration", "corner", "enter", "fill", "smoothMs", "effect", "fxInt", "fxSpeed",
        "gearIcon", "gearSize", "gearOpacity", "gearIdle", "gearBg", "gearBgColor", "gearShape",
        "gearCMode", "gearColor", "gearInset", "panelIdle", "panelY", "panelDur",
        "panelOpenDur", "panelOpenForever", "closeOutside",
        "musicStyle", "musicBars", "musicDepth", "musicSens", "musicOpacity"
    ) + (0..4).map { "tc$it" }

    fun savedPresetNames(): List<String> = ps.all.keys.sorted()

    fun savePreset(name: String) {
        val all = sp.all
        val o = JSONObject()
        for (k in presetKeys) {
            val v = all[k] ?: continue
            o.put(k, v)
        }
        ps.edit().putString(name, o.toString()).apply()
    }

    fun loadPreset(name: String) {
        val json = ps.getString(name, null) ?: return
        val o = JSONObject(json)
        val e = sp.edit()
        for (k in presetKeys) {
            e.remove(k)   // anything the preset does not mention goes back to its default
            if (!o.has(k)) continue
            when (val v = o.get(k)) {
                is Int -> e.putInt(k, v)
                is Boolean -> e.putBoolean(k, v)
            }
        }
        e.apply()
    }

    fun deletePreset(name: String) {
        ps.edit().remove(name).apply()
    }

    private val defaultTc = intArrayOf(
        0xFF00E5FF.toInt(), 0xFFFF9100.toInt(), 0xFFFF1744.toInt(),
        0xFF76FF03.toInt(), 0xFFFFEA00.toInt()
    )

    fun targetColor(i: Int): Int = sp.getInt("tc$i", defaultTc[i])
    fun setTargetColor(i: Int, c: Int) {
        sp.edit().putInt("tc$i", c).apply()
    }
}
