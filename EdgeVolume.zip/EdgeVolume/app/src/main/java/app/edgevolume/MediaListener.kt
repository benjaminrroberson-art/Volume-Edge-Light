package app.edgevolume

import android.service.notification.NotificationListenerService

/**
 * Does nothing itself. Having notification access enabled is what lets the main service
 * see which app currently has an active media session (so you can pick which apps trigger
 * the music light). No notification content is read or stored.
 */
class MediaListener : NotificationListenerService()
