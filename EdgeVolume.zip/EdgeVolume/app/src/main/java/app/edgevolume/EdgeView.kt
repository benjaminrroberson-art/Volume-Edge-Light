package app.edgevolume

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.sin

/**
 * Draws the level along the screen edge(s).
 *
 * Patterns: 0 bottom-up, 1 center-out, 2 center-out wrapping around the phone,
 * 3 clockwise loop around the phone, 4 swell (thicker + brighter).
 * Side patterns are drawn as if for the left edge; the right edge mirrors the canvas.
 */
class EdgeView(ctx: Context) : View(ctx) {

    companion object {
        const val BAR = 0
        const val SEGMENTS = 1
        const val DOT = 2
        const val FULL = 3
    }

    // ---- animated values ----
    var fraction = 0f
        set(v) {
            field = v.coerceIn(0f, 1f)
            invalidate()
        }
    var enter = 1f
        set(v) {
            field = v
            invalidate()
        }
    var phase = 0f
        set(v) {
            field = v
            invalidate()
        }
    var flash = 0f
        set(v) {
            field = v
            invalidate()
        }

    // ---- style ----
    var side = 1
    var shape = BAR
    var pattern = 0
    var colorMode = 0
    var color = Color.CYAN
    var color2 = Color.MAGENTA
    var thicknessPx = 8f
    var glowPx = 48f
    var cornerPx = 80f
    var opacity = 1f
    var effect = 0
    var enterMode = 0
    var motion = 1      // 0 instant, 1 smooth, 2 springy
    var smoothMs = 280
    var fx = 0.8f       // effect intensity 0..1

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val seg = Path()
    private val hsvTmp = FloatArray(3)
    private var glowEff = 48f
    private var hueShift = 0f

    private var shader: Shader? = null
    private var sweep: Shader? = null
    private var shaderW = -1f
    private var shaderH = -1f

    private var armPath = Path()
    private var loopPath = Path()
    private var armMeasure = PathMeasure()
    private var loopMeasure = PathMeasure()
    private var armLen = 1f
    private var loopLen = 1f
    private var pathKey = ""

    // ---- level motion (exponential glide or spring), retargetable at any time ----
    private var pos = 0f
    private var vel = 0f
    private var target = 0f
    private var animating = false
    private var lastNs = 0L
    private val stepper = Runnable { step() }

    fun snapTo(x: Float) {
        target = x
        pos = x
        vel = 0f
        fraction = x
    }

    fun moveTo(x: Float) {
        target = x
        if (motion == 0) {
            pos = x
            vel = 0f
            fraction = x
            return
        }
        if (!animating) {
            animating = true
            lastNs = System.nanoTime()
            postOnAnimation(stepper)
        }
    }

    private fun step() {
        val now = System.nanoTime()
        var dt = ((now - lastNs) / 1_000_000_000f).coerceIn(0f, 0.05f)
        lastNs = now
        val secs = smoothMs.coerceAtLeast(30) / 1000f
        if (motion == 1) {
            val tau = secs / 3f
            pos += (target - pos) * (1f - exp(-dt / tau))
        } else {
            val omega = (2.0 * PI / (secs * 1.2f)).toFloat()
            val zeta = 0.38f
            while (dt > 0f) {
                val h = if (dt < 1f / 240f) dt else 1f / 240f
                dt -= h
                val acc = -omega * omega * (pos - target) - 2f * zeta * omega * vel
                vel += acc * h
                pos += vel * h
            }
        }
        if (abs(target - pos) < 0.0008f && abs(vel) < 0.02f) {
            pos = target
            vel = 0f
            animating = false
        } else {
            postOnAnimation(stepper)
        }
        fraction = pos
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(stepper)
        animating = false
        super.onDetachedFromWindow()
    }

    fun updateColor(c: Int) {
        color = c
        shader = null
        invalidate()
    }

    // ---- color helpers ----
    private fun al(x: Float): Int = (255f * x).toInt().coerceIn(0, 255)

    private fun withA(c: Int, a: Int): Int = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    private fun lerp(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )

    private fun baseColorAt(t: Float): Int = when (colorMode) {
        2 -> lerp(color, color2, t.coerceIn(0f, 1f))
        3 -> Color.HSVToColor(floatArrayOf(t.coerceIn(0f, 1f) * 300f, 0.85f, 1f))
        4 -> Color.HSVToColor(floatArrayOf(120f * (1f - t.coerceIn(0f, 1f)), 0.9f, 1f))
        else -> color
    }

    private fun colorAt(t: Float): Int {
        val c = baseColorAt(t)
        if (effect != 7 || hueShift == 0f) return c
        Color.colorToHSV(c, hsvTmp)
        hsvTmp[0] = ((hsvTmp[0] + hueShift) % 360f + 360f) % 360f
        return Color.HSVToColor(hsvTmp)
    }

    /** 0..1 position used for color: distance from center for center patterns, height otherwise */
    private fun tOfY(y: Float, h: Float): Float =
        if (pattern == 1 || pattern == 2) (abs(y - h / 2f) / (h / 2f)).coerceIn(0f, 1f)
        else (1f - y / h).coerceIn(0f, 1f)

    private fun buildLinear(h: Float): Shader {
        val n = 9
        val stops = FloatArray(n) { it / (n - 1).toFloat() }
        val cols = IntArray(n) { colorAt(tOfY(stops[it] * h, h)) }
        return LinearGradient(0f, 0f, 0f, h, cols, stops, Shader.TileMode.CLAMP)
    }

    private fun buildSweep(w: Float, h: Float): Shader {
        val n = 13
        val stops = FloatArray(n) { it / (n - 1).toFloat() }
        val cols = IntArray(n) { colorAt(stops[it]) }
        val sg = SweepGradient(w / 2f, h / 2f, cols, stops)
        val m = Matrix()
        m.setRotate(-90f, w / 2f, h / 2f)
        sg.setLocalMatrix(m)
        return sg
    }

    private fun ensurePaths(w: Float, h: Float) {
        val key = "$w/$h/$thicknessPx/$cornerPx"
        if (key == pathKey) return
        pathKey = key
        val ins = thicknessPx / 2f
        val rc = if (cornerPx > ins + 2f) cornerPx else ins + 2f

        armPath = Path().apply {
            moveTo(ins, h / 2f)
            lineTo(ins, rc)
            arcTo(RectF(ins, ins, 2f * rc - ins, 2f * rc - ins), 180f, 90f)
            lineTo(w / 2f, ins)
        }
        armMeasure = PathMeasure(armPath, false)
        armLen = armMeasure.length.coerceAtLeast(1f)

        loopPath = Path().apply {
            moveTo(w / 2f, ins)
            lineTo(w - rc, ins)
            arcTo(RectF(w - 2f * rc + ins, ins, w - ins, 2f * rc - ins), 270f, 90f)
            lineTo(w - ins, h - rc)
            arcTo(RectF(w - 2f * rc + ins, h - 2f * rc + ins, w - ins, h - ins), 0f, 90f)
            lineTo(rc, h - ins)
            arcTo(RectF(ins, h - 2f * rc + ins, 2f * rc - ins, h - ins), 90f, 90f)
            lineTo(ins, rc)
            arcTo(RectF(ins, ins, 2f * rc - ins, 2f * rc - ins), 180f, 90f)
            lineTo(w / 2f, ins)
        }
        loopMeasure = PathMeasure(loopPath, false)
        loopLen = loopMeasure.length.coerceAtLeast(1f)
    }

    private fun pulseFactor(): Float =
        if (effect == 1) 1f - 0.65f * fx * (0.5f - 0.5f * sin(2.0 * PI * phase).toFloat()) else 1f

    // ---- drawing ----
    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val sw = sin(2.0 * PI * phase).toFloat()
        hueShift = if (effect == 7) fx * 180f * sw else 0f
        glowEff = glowPx * (if (effect == 4) (1f + 0.8f * fx * sw).coerceAtLeast(0.15f) else 1f)
        if (effect == 7) shader = null
        if (shader == null || shaderW != w || shaderH != h) {
            shader = buildLinear(h)
            sweep = buildSweep(w, h)
            shaderW = w
            shaderH = h
        }
        val e = if (enterMode == 2) 1f else enter.coerceIn(0f, 1f)
        val a = opacity * (if (enterMode == 1) (e * 1.6f).coerceAtMost(1f) else e)

        if (pattern == 3) {
            drawLoop(canvas, w, h, a)
            return
        }
        if (side == 0 || side == 2) drawEdge(canvas, w, h, a, e, true)
        if (side == 1 || side == 2) drawEdge(canvas, w, h, a, e, false)
    }

    private fun drawEdge(c: Canvas, w: Float, h: Float, a: Float, e: Float, left: Boolean) {
        c.save()
        if (!left) {
            c.translate(w, 0f)
            c.scale(-1f, 1f)
        }
        if (enterMode == 1 && pattern != 2) c.translate(-(1f - e) * (thicknessPx + glowPx), 0f)
        when (pattern) {
            0 -> drawLinear(c, h, a, false)
            1 -> drawLinear(c, h, a, true)
            2 -> drawWrap(c, w, h, a)
            else -> drawSwell(c, h, a)
        }
        c.restore()
    }

    private fun drawLinear(c: Canvas, h: Float, a: Float, centered: Boolean) {
        val f = fraction
        val th = thicknessPx
        val rr = th / 2f
        val lo = if (centered) h * (0.5f - f / 2f) else h * (1f - f)
        val hi = if (centered) h * (0.5f + f / 2f) else h
        val pulse = pulseFactor()

        when (shape) {
            BAR -> {
                paint.shader = shader
                paint.alpha = al(a * 0.16f)
                c.drawRect(0f, 0f, th, h, paint)
                if (f > 0.002f) {
                    drawGlow(c, lo, hi, a * pulse, th, 1f)
                    paint.shader = shader
                    paint.alpha = al(a)
                    rect.set(0f, lo, th, hi)
                    if (effect == 6) drawWaveCore(c, lo, hi, h, th) else c.drawRoundRect(rect, rr, rr, paint)
                    if (effect == 2) drawShimmer(c, lo, hi, h, th, a, centered)
                    if (effect == 5) drawComet(c, lo, hi, h, th, a, centered)
                    if (flash > 0f) {
                        paint.shader = null
                        paint.color = Color.WHITE
                        paint.alpha = al(flash * 0.9f * fx * a)
                        c.drawRoundRect(rect, rr, rr, paint)
                    }
                }
            }

            SEGMENTS -> {
                val n = 16
                val pad = h * 0.07f
                val segH = (h - 2 * pad) / n
                paint.shader = shader
                val gl = if (lo > pad) lo else pad
                val gh = if (hi < h - pad) hi else h - pad
                if (f > 0.002f && gh > gl) drawGlow(c, gl, gh, a * pulse * 0.6f, th, 1f)
                paint.shader = shader
                for (i in 0 until n) {
                    val yt = pad + i * segH
                    val yb = yt + segH * 0.78f
                    val top = if (lo > yt) lo else yt
                    val bot = if (hi < yb) hi else yb
                    val ov = ((bot - top) / (yb - yt)).coerceIn(0f, 1f)
                    paint.alpha = al(a * (if (ov > 0f) 0.3f + 0.7f * ov else 0.14f))
                    rect.set(0f, yt, th, yb)
                    c.drawRoundRect(rect, rr, rr, paint)
                }
            }

            DOT -> {
                val pad = h * 0.06f
                paint.shader = shader
                paint.alpha = al(a * 0.3f)
                if (!centered) {
                    val y = pad + (h - 2 * pad) * (1f - f)
                    c.drawRect(0f, y, th * 0.5f, h - pad, paint)
                    drawDot(c, y, h, a, pulse)
                } else {
                    val d = f * (h / 2f - pad)
                    val y1 = h / 2f - d
                    val y2 = h / 2f + d
                    c.drawRect(0f, y1, th * 0.5f, y2, paint)
                    drawDot(c, y1, h, a, pulse)
                    drawDot(c, y2, h, a, pulse)
                }
            }

            else -> { // FULL
                val k = 0.2f + 0.8f * f
                paint.shader = shader
                paint.alpha = al(a * k * pulse)
                c.drawRect(0f, 0f, th, h, paint)
                drawGlow(c, 0f, h, a * pulse * k, th, 0.35f + 0.65f * f)
            }
        }
        paint.shader = null
    }

    private fun drawDot(c: Canvas, y: Float, h: Float, a: Float, pulse: Float) {
        val th = thicknessPx
        val cx = th * 1.2f
        val r = th * 1.4f
        val big = r + glowEff
        val col = colorAt(tOfY(y, h))
        paint.shader = RadialGradient(
            cx, y, big,
            intArrayOf(
                withA(col, al(a * pulse * 0.9f)),
                withA(col, al(a * pulse * 0.35f)),
                withA(col, 0)
            ),
            floatArrayOf(0f, (r / big).coerceIn(0.01f, 0.9f), 1f),
            Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, y, big, paint)
        paint.shader = null
        paint.color = col
        paint.alpha = al(a)
        c.drawCircle(cx, y, r, paint)
        if (flash > 0f) {
            paint.color = Color.WHITE
            paint.alpha = al(flash * 0.9f * fx * a)
            c.drawCircle(cx, y, r, paint)
        }
    }

    /** Whole edge lit; gets thicker, brighter and glows wider as the level rises. */
    private fun drawSwell(c: Canvas, h: Float, a: Float) {
        val f = fraction
        val pulse = pulseFactor()
        val k = 0.15f + 0.85f * f
        val th = thicknessPx * (0.3f + 1.7f * f)
        paint.shader = null
        paint.color = colorAt(f)
        paint.alpha = al(a * k * pulse)
        c.drawRect(0f, 0f, th, h, paint)
        drawGlow(c, 0f, h, a * pulse * k, th, 0.2f + 0.8f * f)
        if (flash > 0f) {
            paint.color = Color.WHITE
            paint.alpha = al(flash * 0.6f * fx * a)
            c.drawRect(0f, 0f, th, h, paint)
        }
    }

    /** Light spreads from the vertical center up and down, around the corners, toward top/bottom center. */
    private fun drawWrap(c: Canvas, w: Float, h: Float, a: Float) {
        ensurePaths(w, h)
        val f = fraction
        val pulse = pulseFactor()
        paint.shader = shader

        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeWidth = thicknessPx
        paint.alpha = al(a * 0.13f)
        c.drawPath(armPath, paint)
        c.save()
        c.translate(0f, h)
        c.scale(1f, -1f)
        c.drawPath(armPath, paint)
        c.restore()

        if (f > 0.002f) {
            seg.reset()
            armMeasure.getSegment(0f, armLen * f, seg, true)
            seg.rLineTo(0f, 0f)
            strokeGlowCore(c, seg, a, pulse)
            c.save()
            c.translate(0f, h)
            c.scale(1f, -1f)
            strokeGlowCore(c, seg, a, pulse)
            c.restore()
        }
        paint.style = Paint.Style.FILL
        paint.shader = null
    }

    /** Light travels clockwise around the whole phone, starting at top center. */
    private fun drawLoop(c: Canvas, w: Float, h: Float, a: Float) {
        ensurePaths(w, h)
        val f = fraction
        val pulse = pulseFactor()
        paint.shader = if (colorMode == 0 || colorMode == 1) shader else sweep

        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeWidth = thicknessPx
        paint.alpha = al(a * 0.13f)
        c.drawPath(loopPath, paint)

        if (f > 0.002f) {
            seg.reset()
            loopMeasure.getSegment(0f, loopLen * f, seg, true)
            seg.rLineTo(0f, 0f)
            strokeGlowCore(c, seg, a, pulse)
        }
        paint.style = Paint.Style.FILL
        paint.shader = null
    }

    private fun strokeGlowCore(c: Canvas, p: Path, a: Float, glowMult: Float) {
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        if (glowEff > 0f) {
            val n = 9
            for (i in n - 1 downTo 0) {
                val k = 1f - i.toFloat() / n
                paint.strokeWidth = thicknessPx + 2f * glowEff * (i + 1) / n
                paint.alpha = al(a * glowMult * 0.2f * k * k)
                c.drawPath(p, paint)
            }
        }
        paint.strokeWidth = thicknessPx
        paint.alpha = al(a)
        c.drawPath(p, paint)
    }

    /** Glow beside a straight bar; uses whatever shader/color is already set on the paint. */
    private fun drawGlow(c: Canvas, top: Float, bottom: Float, a: Float, th: Float, widthScale: Float) {
        if (glowEff <= 0f || bottom <= top) return
        val n = 14
        val gw = glowEff * widthScale
        for (i in n - 1 downTo 0) {
            val k = 1f - i.toFloat() / n
            paint.alpha = al(a * 0.17f * k * k)
            c.drawRect(0f, top, th + gw * (i + 1) / n, bottom, paint)
        }
    }

    /** Bar whose width ripples along its length. */
    private fun drawWaveCore(c: Canvas, lo: Float, hi: Float, h: Float, th: Float) {
        val step = (3f * resources.displayMetrics.density).coerceAtLeast(2f)
        val len = h * 0.22f
        var y = lo
        while (y < hi) {
            val y2 = if (y + step < hi) y + step else hi
            val m = 1f + fx * 0.9f * sin(2.0 * PI * ((y / len) - phase)).toFloat()
            val ww = (th * m).coerceAtLeast(th * 0.25f)
            c.drawRect(0f, y, ww, y2 + 0.5f, paint)
            y = y2
        }
    }

    /** A bright head racing along the bar, leaving a fading tail. */
    private fun drawComet(c: Canvas, lo: Float, hi: Float, h: Float, th: Float, a: Float, centered: Boolean) {
        val tail = (hi - lo) * (0.12f + 0.5f * fx)
        c.save()
        c.clipRect(0f, lo, th, hi)
        fun band(head: Float, dir: Float) {
            val end = head + dir * tail
            paint.shader = LinearGradient(
                0f, head, 0f, end,
                intArrayOf(0xF0FFFFFF.toInt(), 0x00FFFFFF), null, Shader.TileMode.CLAMP
            )
            paint.alpha = al(a * (0.3f + 0.7f * fx))
            val t0 = if (head < end) head else end
            val t1 = if (head < end) end else head
            c.drawRect(0f, t0, th, t1, paint)
        }
        if (centered) {
            band(h / 2f - phase * (h / 2f - lo), 1f)
            band(h / 2f + phase * (hi - h / 2f), -1f)
        } else {
            band(hi - phase * (hi - lo), 1f)
        }
        c.restore()
    }

    private fun drawShimmer(c: Canvas, lo: Float, hi: Float, h: Float, th: Float, a: Float, centered: Boolean) {
        val bh = h * 0.14f
        val ys = if (centered) {
            floatArrayOf(h / 2f - phase * (h / 2f - lo), h / 2f + phase * (hi - h / 2f))
        } else {
            floatArrayOf(hi - phase * (hi - lo))
        }
        c.save()
        c.clipRect(0f, lo, th, hi)
        for (yc in ys) {
            paint.shader = LinearGradient(
                0f, yc + bh, 0f, yc - bh,
                intArrayOf(0x00FFFFFF, 0xBFFFFFFF.toInt(), 0x00FFFFFF),
                null, Shader.TileMode.CLAMP
            )
            paint.alpha = al(a * fx)
            c.drawRect(0f, yc - bh, th, yc + bh, paint)
        }
        c.restore()
    }
}
