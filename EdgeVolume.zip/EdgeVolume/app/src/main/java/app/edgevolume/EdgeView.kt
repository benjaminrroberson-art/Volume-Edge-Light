package app.edgevolume

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import kotlin.math.PI
import kotlin.math.sin

/**
 * Draws the volume/brightness level along the left and/or right screen edge.
 * Everything is drawn as if for the left edge; the right edge mirrors the canvas.
 */
class EdgeView(ctx: Context) : View(ctx) {

    companion object {
        const val BAR = 0
        const val SEGMENTS = 1
        const val DOT = 2
        const val FULL = 3
    }

    var fraction = 0f
        set(v) {
            field = v.coerceIn(0f, 1f)
            invalidate()
        }
    var enter = 1f
        set(v) {
            field = v
            invalidate()
        }
    var phase = 0f
        set(v) {
            field = v
            invalidate()
        }
    var flash = 0f
        set(v) {
            field = v
            invalidate()
        }

    var side = 1
    var shape = BAR
    var colorMode = 0
    var color = Color.CYAN
    var color2 = Color.MAGENTA
    var thicknessPx = 8f
    var glowPx = 48f
    var opacity = 1f
    var effect = 0
    var enterMode = 0

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var shader: Shader? = null
    private var shaderH = -1f

    fun updateColor(c: Int) {
        color = c
        shader = null
        invalidate()
    }

    private fun al(x: Float): Int = (255f * x).toInt().coerceIn(0, 255)

    private fun withA(c: Int, a: Int): Int = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    private fun lerp(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )

    /** t = 0 at the bottom of the screen, 1 at the top */
    private fun colorAt(t: Float): Int = when (colorMode) {
        2 -> lerp(color, color2, t)
        3 -> Color.HSVToColor(floatArrayOf(t * 300f, 0.85f, 1f))
        4 -> Color.HSVToColor(floatArrayOf(120f * (1f - t), 0.9f, 1f))
        else -> color
    }

    private fun buildShader(h: Float): Shader {
        val n = 9
        val stops = FloatArray(n) { it / (n - 1).toFloat() }
        val cols = IntArray(n) { colorAt(stops[it]) }
        return LinearGradient(0f, h, 0f, 0f, cols, stops, Shader.TileMode.CLAMP)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (shader == null || shaderH != h) {
            shader = buildShader(h)
            shaderH = h
        }
        val e = if (enterMode == 2) 1f else enter.coerceIn(0f, 1f)
        val a = opacity * (if (enterMode == 1) (e * 1.6f).coerceAtMost(1f) else e)
        if (side == 0 || side == 2) drawEdge(canvas, w, h, a, e, true)
        if (side == 1 || side == 2) drawEdge(canvas, w, h, a, e, false)
    }

    private fun drawEdge(c: Canvas, w: Float, h: Float, a: Float, e: Float, left: Boolean) {
        c.save()
        if (!left) {
            c.translate(w, 0f)
            c.scale(-1f, 1f)
        }
        if (enterMode == 1) c.translate(-(1f - e) * (thicknessPx + glowPx), 0f)
        drawLeft(c, h, a)
        c.restore()
    }

    private fun drawLeft(c: Canvas, h: Float, a: Float) {
        val f = fraction
        val pulse = if (effect == 1) {
            0.65f + 0.35f * (0.5f + 0.5f * sin(2.0 * PI * phase).toFloat())
        } else 1f
        val rr = thicknessPx / 2f

        when (shape) {
            BAR -> {
                paint.shader = shader
                paint.alpha = al(a * 0.16f)
                c.drawRect(0f, 0f, thicknessPx, h, paint)
                if (f > 0f) {
                    val top = h * (1f - f)
                    drawGlow(c, top, h, a * pulse, 1f)
                    paint.shader = shader
                    paint.alpha = al(a)
                    rect.set(0f, top, thicknessPx, h)
                    c.drawRoundRect(rect, rr, rr, paint)
                    if (effect == 2) drawShimmer(c, top, h, a)
                    if (flash > 0f) {
                        paint.shader = null
                        paint.color = Color.WHITE
                        paint.alpha = al(flash * 0.7f * a)
                        c.drawRoundRect(rect, rr, rr, paint)
                    }
                }
            }

            SEGMENTS -> {
                val n = 16
                val pad = h * 0.07f
                val segH = (h - 2 * pad) / n
                val lit = f * n
                if (lit > 0f) drawGlow(c, h - pad - lit * segH, h - pad, a * pulse * 0.6f, 1f)
                paint.shader = shader
                for (i in 0 until n) {
                    val on = (lit - i).coerceIn(0f, 1f)
                    val yb = h - pad - i * segH
                    val yt = yb - segH * 0.78f
                    paint.alpha = al(a * (if (on > 0f) 0.3f + 0.7f * on else 0.14f))
                    rect.set(0f, yt, thicknessPx, yb)
                    c.drawRoundRect(rect, rr, rr, paint)
                }
            }

            DOT -> {
                val pad = h * 0.06f
                val y = pad + (h - 2 * pad) * (1f - f)
                paint.shader = shader
                paint.alpha = al(a * 0.3f)
                c.drawRect(0f, y, thicknessPx * 0.5f, h - pad, paint)
                val cx = thicknessPx * 1.2f
                val r = thicknessPx * 1.4f
                val big = r + glowPx
                val col = colorAt(f)
                paint.shader = RadialGradient(
                    cx, y, big,
                    intArrayOf(
                        withA(col, al(a * pulse * 0.9f)),
                        withA(col, al(a * pulse * 0.35f)),
                        withA(col, 0)
                    ),
                    floatArrayOf(0f, (r / big).coerceIn(0.01f, 0.9f), 1f),
                    Shader.TileMode.CLAMP
                )
                c.drawCircle(cx, y, big, paint)
                paint.shader = null
                paint.color = col
                paint.alpha = al(a)
                c.drawCircle(cx, y, r, paint)
                if (flash > 0f) {
                    paint.color = Color.WHITE
                    paint.alpha = al(flash * 0.7f * a)
                    c.drawCircle(cx, y, r, paint)
                }
            }

            else -> { // FULL
                val k = 0.2f + 0.8f * f
                paint.shader = shader
                paint.alpha = al(a * k * pulse)
                c.drawRect(0f, 0f, thicknessPx, h, paint)
                drawGlow(c, 0f, h, a * pulse * k, 0.35f + 0.65f * f)
            }
        }
        paint.shader = null
    }

    private fun drawGlow(c: Canvas, top: Float, bottom: Float, a: Float, widthScale: Float) {
        if (glowPx <= 0f) return
        paint.shader = shader
        val n = 14
        val gw = glowPx * widthScale
        for (i in n - 1 downTo 0) {
            val k = 1f - i.toFloat() / n
            paint.alpha = al(a * 0.17f * k * k)
            c.drawRect(0f, top, thicknessPx + gw * (i + 1) / n, bottom, paint)
        }
    }

    private fun drawShimmer(c: Canvas, top: Float, h: Float, a: Float) {
        val bh = h * 0.14f
        val yc = h - phase * (h - top)
        c.save()
        c.clipRect(0f, top, thicknessPx, h)
        paint.shader = LinearGradient(
            0f, yc + bh, 0f, yc - bh,
            intArrayOf(0x00FFFFFF, 0xBFFFFFFF.toInt(), 0x00FFFFFF),
            null, Shader.TileMode.CLAMP
        )
        paint.alpha = al(a)
        c.drawRect(0f, yc - bh, thicknessPx, yc + bh, paint)
        c.restore()
    }
}
