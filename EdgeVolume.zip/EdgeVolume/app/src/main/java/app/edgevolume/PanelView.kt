package app.edgevolume

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

/** Small touchable panel: ringer-mode button on top, "which volume am I controlling" button below. */
class PanelView(
    ctx: Context,
    accent: Int,
    private val getTarget: () -> Int,
    private val getRinger: () -> Int,
    private val onMode: () -> Unit,
    private val onTarget: () -> Unit
) : LinearLayout(ctx) {

    private val modeIcon = TextView(ctx)
    private val modeCap = TextView(ctx)
    private val tgtIcon = TextView(ctx)
    private val tgtCap = TextView(ctx)

    init {
        orientation = VERTICAL
        val d = ctx.resources.displayMetrics.density
        fun dp(x: Int) = (x * d).toInt()

        setPadding(dp(4), dp(6), dp(4), dp(6))
        background = GradientDrawable().apply {
            cornerRadius = 22 * d
            setColor(0xE6141A22.toInt())
            setStroke(
                dp(2),
                Color.argb(150, Color.red(accent), Color.green(accent), Color.blue(accent))
            )
        }

        addView(cell(modeIcon, modeCap, dp(56), dp(56)) { onMode() })
        addView(cell(tgtIcon, tgtCap, dp(56), dp(56)) { onTarget() })
        refresh()
    }

    private fun cell(icon: TextView, cap: TextView, w: Int, h: Int, click: () -> Unit): LinearLayout {
        icon.textSize = 22f
        icon.gravity = Gravity.CENTER
        cap.textSize = 9f
        cap.gravity = Gravity.CENTER
        cap.setTextColor(0xB3FFFFFF.toInt())
        return LinearLayout(context).apply {
            orientation = VERTICAL
            gravity = Gravity.CENTER
            minimumWidth = w
            minimumHeight = h
            addView(icon)
            addView(cap)
            setOnClickListener { click() }
        }
    }

    fun refresh() {
        when (getRinger()) {
            AudioManager.RINGER_MODE_NORMAL -> {
                modeIcon.text = "🔔"
                modeCap.text = "Ring"
            }
            AudioManager.RINGER_MODE_VIBRATE -> {
                modeIcon.text = "📳"
                modeCap.text = "Vibrate"
            }
            else -> {
                modeIcon.text = "🔕"
                modeCap.text = "Silent"
            }
        }
        val t = getTarget()
        tgtIcon.text = VolumeService.ICONS[t]
        tgtCap.text = VolumeService.NAMES[t]
    }
}
