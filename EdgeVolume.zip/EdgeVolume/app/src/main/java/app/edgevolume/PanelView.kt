package app.edgevolume

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

/** Look of the gear button. */
class GearStyle(
    val icon: Int,        // 0 gear, 1 dots, 2 sliders, 3 bars, 4 ring, 5 chevron
    val sizePx: Int,
    val opacity: Float,
    val bgStyle: Int,     // 0 dark disc, 1 none, 2 filled, 3 outline
    val bgColor: Int,
    val shape: Int,       // 0 circle, 1 rounded square
    val accent: Int,
    val onRight: Boolean
)

/**
 * A single small button. Tapping it opens a card with text chips:
 * ringer mode and which thing the volume keys control.
 */
class PanelView(
    ctx: Context,
    private val style: GearStyle,
    private val getTarget: () -> Int,
    private val getRinger: () -> Int,
    private val getTargets: () -> List<Int>,
    private val silentAllowed: () -> Boolean,
    private val onRinger: (Int) -> Unit,
    private val onTarget: (Int) -> Unit,
    private val onTouched: () -> Unit
) : LinearLayout(ctx) {

    private val accent = style.accent
    private val d = ctx.resources.displayMetrics.density
    private fun dp(x: Int) = (x * d).toInt()
    private fun withAlpha(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    private var expanded = false
    private var lastSig = ""
    private val gear = GearView(ctx, style)
    private val body = LinearLayout(ctx)

    init {
        orientation = VERTICAL
        gravity = if (style.onRight) Gravity.END else Gravity.START

        gear.alpha = style.opacity
        gear.setOnClickListener {
            expanded = !expanded
            body.visibility = if (expanded) VISIBLE else GONE
            lastSig = ""
            refresh()
            onTouched()
        }
        addView(gear, LayoutParams(style.sizePx, style.sizePx))

        body.orientation = VERTICAL
        body.visibility = GONE
        body.setPadding(dp(12), dp(10), dp(12), dp(12))
        body.background = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat()
            setColor(withAlpha(style.bgColor, 0xEB))
            setStroke(dp(1), withAlpha(accent, 120))
        }
        addView(body, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(6)
        })
    }

    fun isExpanded(): Boolean = expanded

    fun collapse() {
        expanded = false
        body.visibility = GONE
    }

    /** Rebuild the chips if (and only if) something they show has changed. */
    fun refresh() {
        if (!expanded) return
        val targets = getTargets()
        val sig = "${getTarget()}|${getRinger()}|${silentAllowed()}|$targets"
        if (sig == lastSig) return
        lastSig = sig

        body.removeAllViews()
        body.addView(caption("RINGER"))
        val row = LinearLayout(context).apply { orientation = HORIZONTAL }
        val modes = listOf(
            AudioManager.RINGER_MODE_NORMAL to "Ring",
            AudioManager.RINGER_MODE_VIBRATE to "Vibrate",
            AudioManager.RINGER_MODE_SILENT to "Silent"
        )
        modes.forEach { (mode, label) ->
            row.addView(
                chip(label, getRinger() == mode, silentAllowed() || mode != AudioManager.RINGER_MODE_SILENT) {
                    onRinger(mode)
                },
                LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply {
                    marginEnd = dp(6)
                }
            )
        }
        body.addView(row)

        body.addView(caption("KEYS CONTROL"))
        targets.forEach { t ->
            body.addView(
                chip(VolumeService.NAMES[t], getTarget() == t, true) { onTarget(t) },
                LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply {
                    topMargin = dp(5)
                }
            )
        }
    }

    private fun caption(t: String) = TextView(context).apply {
        text = t
        textSize = 9f
        letterSpacing = 0.12f
        setTextColor(withAlpha(accent, 150))
        setPadding(dp(2), dp(8), 0, dp(5))
    }

    private fun chip(label: String, selected: Boolean, enabled: Boolean, click: () -> Unit): TextView =
        TextView(context).apply {
            text = label
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(7), dp(14), dp(7))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                if (selected) {
                    setColor(accent)
                } else {
                    setColor(0)
                    setStroke(dp(1), withAlpha(accent, 140))
                }
            }
            setTextColor(if (selected) 0xFF0E1218.toInt() else withAlpha(accent, 235))
            alpha = if (enabled) 1f else 0.45f
            setOnClickListener {
                click()
                lastSig = ""
                refresh()
                onTouched()
            }
        }
}

/** The button itself, drawn in code: background shape plus one of six minimal icons. */
internal class GearView(ctx: Context, private val st: GearStyle) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()
    private val bar = RectF()
    private var gear = Path()
    private val chevron = Path()

    init {
        ring.style = Paint.Style.STROKE
        ring.strokeWidth = 1.5f * d
        fg.strokeCap = Paint.Cap.ROUND
        fg.strokeJoin = Paint.Join.ROUND
    }

    private fun withAlpha(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val cx = w / 2f
        val cy = h / 2f
        val r = w * 0.27f
        val p = Path()
        p.addCircle(cx, cy, r * 0.68f, Path.Direction.CW)
        val m = Matrix()
        for (i in 0 until 8) {
            val tooth = Path()
            tooth.addRoundRect(
                cx - r * 0.17f, cy - r, cx + r * 0.17f, cy - r * 0.55f,
                r * 0.08f, r * 0.08f, Path.Direction.CW
            )
            m.setRotate(i * 45f, cx, cy)
            tooth.transform(m)
            p.addPath(tooth)
        }
        p.addCircle(cx, cy, r * 0.3f, Path.Direction.CCW)
        gear = p
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val cx = w / 2f
        val cy = height / 2f
        val acc = st.accent
        val inset = 1.5f * d
        box.set(inset, inset, w - inset, w - inset)
        val rad = if (st.shape == 1) w * 0.28f else w / 2f

        when (st.bgStyle) {
            0 -> {
                fill.style = Paint.Style.FILL
                fill.color = withAlpha(st.bgColor, 0xE6)
                c.drawRoundRect(box, rad, rad, fill)
                ring.color = withAlpha(acc, 150)
                c.drawRoundRect(box, rad, rad, ring)
            }
            2 -> {
                fill.style = Paint.Style.FILL
                fill.color = acc
                c.drawRoundRect(box, rad, rad, fill)
            }
            3 -> {
                ring.color = withAlpha(acc, 210)
                c.drawRoundRect(box, rad, rad, ring)
            }
        }

        fg.color = if (st.bgStyle == 2) 0xFF0E1218.toInt() else acc
        fg.style = Paint.Style.FILL

        when (st.icon) {
            0 -> c.drawPath(gear, fg)

            1 -> {
                for (k in -1..1) c.drawCircle(cx, cy + k * w * 0.17f, w * 0.055f, fg)
            }

            2 -> {
                val xs = floatArrayOf(-0.08f, 0.1f, -0.03f)
                fg.style = Paint.Style.STROKE
                fg.strokeWidth = w * 0.04f
                for (k in 0..2) {
                    val y = cy + (k - 1) * w * 0.17f
                    c.drawLine(cx - w * 0.22f, y, cx + w * 0.22f, y, fg)
                }
                fg.style = Paint.Style.FILL
                for (k in 0..2) {
                    val y = cy + (k - 1) * w * 0.17f
                    c.drawCircle(cx + xs[k] * w, y, w * 0.065f, fg)
                }
            }

            3 -> {
                val hs = floatArrayOf(0.16f, 0.32f, 0.22f)
                val bw = w * 0.07f
                val base = cy + w * 0.16f
                for (k in 0..2) {
                    val x = cx + (k - 1) * w * 0.14f
                    bar.set(x - bw / 2f, base - hs[k] * w, x + bw / 2f, base)
                    c.drawRoundRect(bar, bw / 2f, bw / 2f, fg)
                }
            }

            4 -> {
                fg.style = Paint.Style.STROKE
                fg.strokeWidth = w * 0.05f
                c.drawCircle(cx, cy, w * 0.17f, fg)
                fg.style = Paint.Style.FILL
                c.drawCircle(cx, cy, w * 0.055f, fg)
            }

            else -> {
                val dir = if (st.onRight) -1f else 1f   // chevron points toward the screen's center
                val tipX = cx + dir * w * 0.08f
                val tailX = cx - dir * w * 0.07f
                chevron.reset()
                chevron.moveTo(tailX, cy - w * 0.17f)
                chevron.lineTo(tipX, cy)
                chevron.lineTo(tailX, cy + w * 0.17f)
                fg.style = Paint.Style.STROKE
                fg.strokeWidth = w * 0.06f
                c.drawPath(chevron, fg)
            }
        }
    }
}
