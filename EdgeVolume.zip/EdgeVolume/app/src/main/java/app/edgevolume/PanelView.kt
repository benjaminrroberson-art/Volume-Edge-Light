package app.edgevolume

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

/**
 * A single small gear button. Tapping it opens a card with text chips:
 * ringer mode and which thing the volume keys control.
 */
class PanelView(
    ctx: Context,
    private val accent: Int,
    onRight: Boolean,
    private val getTarget: () -> Int,
    private val getRinger: () -> Int,
    private val getTargets: () -> List<Int>,
    private val silentAllowed: () -> Boolean,
    private val onRinger: (Int) -> Unit,
    private val onTarget: (Int) -> Unit,
    private val onTouched: () -> Unit
) : LinearLayout(ctx) {

    private val d = ctx.resources.displayMetrics.density
    private fun dp(x: Int) = (x * d).toInt()
    private fun withAlpha(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    private var expanded = false
    private var lastSig = ""
    private val gear = GearView(ctx, accent)
    private val body = LinearLayout(ctx)

    init {
        orientation = VERTICAL
        gravity = if (onRight) Gravity.END else Gravity.START

        gear.setOnClickListener {
            expanded = !expanded
            body.visibility = if (expanded) VISIBLE else GONE
            lastSig = ""
            refresh()
            onTouched()
        }
        addView(gear, LayoutParams(dp(44), dp(44)))

        body.orientation = VERTICAL
        body.visibility = GONE
        body.setPadding(dp(12), dp(10), dp(12), dp(12))
        body.background = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat()
            setColor(0xEB141A22.toInt())
            setStroke(dp(1), withAlpha(accent, 120))
        }
        addView(body, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(6)
        })
    }

    fun collapse() {
        expanded = false
        body.visibility = GONE
    }

    /** Rebuild the chips if (and only if) something they show has changed. */
    fun refresh() {
        if (!expanded) return
        val targets = getTargets()
        val sig = "${getTarget()}|${getRinger()}|${silentAllowed()}|$targets"
        if (sig == lastSig) return
        lastSig = sig

        body.removeAllViews()
        body.addView(caption("RINGER"))
        val row = LinearLayout(context).apply { orientation = HORIZONTAL }
        val modes = listOf(
            AudioManager.RINGER_MODE_NORMAL to "Ring",
            AudioManager.RINGER_MODE_VIBRATE to "Vibrate",
            AudioManager.RINGER_MODE_SILENT to "Silent"
        )
        modes.forEach { (mode, label) ->
            row.addView(
                chip(label, getRinger() == mode, silentAllowed() || mode != AudioManager.RINGER_MODE_SILENT) {
                    onRinger(mode)
                },
                LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply {
                    marginEnd = dp(6)
                }
            )
        }
        body.addView(row)

        body.addView(caption("KEYS CONTROL"))
        targets.forEach { t ->
            body.addView(
                chip(VolumeService.NAMES[t], getTarget() == t, true) { onTarget(t) },
                LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply {
                    topMargin = dp(5)
                }
            )
        }
    }

    private fun caption(t: String) = TextView(context).apply {
        text = t
        textSize = 9f
        letterSpacing = 0.12f
        setTextColor(withAlpha(accent, 150))
        setPadding(dp(2), dp(8), 0, dp(5))
    }

    private fun chip(label: String, selected: Boolean, enabled: Boolean, click: () -> Unit): TextView =
        TextView(context).apply {
            text = label
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(7), dp(14), dp(7))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                if (selected) {
                    setColor(accent)
                } else {
                    setColor(0)
                    setStroke(dp(1), withAlpha(accent, 140))
                }
            }
            setTextColor(if (selected) 0xFF0E1218.toInt() else withAlpha(accent, 235))
            alpha = if (enabled) 1f else 0.45f
            setOnClickListener {
                click()
                lastSig = ""
                refresh()
                onTouched()
            }
        }
}

/** Minimal gear drawn in code: dark disc, thin accent ring, accent gear with a hole. */
internal class GearView(ctx: Context, private val accent: Int) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fg = Paint(Paint.ANTI_ALIAS_FLAG)
    private var gear = Path()

    init {
        bg.color = 0xE6141A22.toInt()
        ring.style = Paint.Style.STROKE
        ring.strokeWidth = 1.5f * d
        ring.color = Color.argb(150, Color.red(accent), Color.green(accent), Color.blue(accent))
        fg.color = accent
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val cx = w / 2f
        val cy = h / 2f
        val r = w * 0.27f
        val p = Path()
        p.addCircle(cx, cy, r * 0.68f, Path.Direction.CW)
        val m = Matrix()
        for (i in 0 until 8) {
            val tooth = Path()
            tooth.addRoundRect(
                cx - r * 0.17f, cy - r, cx + r * 0.17f, cy - r * 0.55f,
                r * 0.08f, r * 0.08f, Path.Direction.CW
            )
            m.setRotate(i * 45f, cx, cy)
            tooth.transform(m)
            p.addPath(tooth)
        }
        p.addCircle(cx, cy, r * 0.3f, Path.Direction.CCW)
        gear = p
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        c.drawCircle(cx, cy, width / 2f - d, bg)
        c.drawCircle(cx, cy, width / 2f - 1.5f * d, ring)
        c.drawPath(gear, fg)
    }
}
