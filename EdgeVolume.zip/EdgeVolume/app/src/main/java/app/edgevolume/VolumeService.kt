package app.edgevolume

import android.accessibilityservice.AccessibilityService
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.database.ContentObserver
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.Toast
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Accessibility service that
 *  - swallows the hardware volume keys (so the system panel never shows),
 *  - adjusts the selected target (media / ring / alarm / call / brightness),
 *  - draws the edge light and a small touchable control panel as accessibility overlays.
 */
class VolumeService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: VolumeService? = null

        val STREAMS = intArrayOf(
            AudioManager.STREAM_MUSIC,
            AudioManager.STREAM_RING,
            AudioManager.STREAM_ALARM,
            AudioManager.STREAM_VOICE_CALL
        )
        const val T_BRIGHT = 4
        val NAMES = arrayOf("Media", "Ring", "Alarm", "Call", "Bright")
        val ICONS = arrayOf("🎵", "📲", "⏰", "🗣", "☀️")
    }

    private lateinit var prefs: Prefs
    private lateinit var wm: WindowManager
    private lateinit var am: AudioManager
    private lateinit var nm: NotificationManager
    private val handler = Handler(Looper.getMainLooper())
    private var ready = false

    private var edge: EdgeView? = null
    private var panel: PanelView? = null

    private val lastVolume = HashMap<Int, Int>()
    private val fracs = FloatArray(5)

    private var phaseAnim: ValueAnimator? = null
    private var fillAnim: ValueAnimator? = null
    private var enterAnim: ValueAnimator? = null
    private var flashAnim: ValueAnimator? = null

    private val hideLight = Runnable { hideEdge() }
    private val hidePanel = Runnable { hidePanelNow() }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                "android.media.VOLUME_CHANGED_ACTION" -> checkVolumes()
                AudioManager.RINGER_MODE_CHANGED_ACTION -> panel?.refresh()
            }
        }
    }

    private val observer = object : ContentObserver(handler) {
        override fun onChange(selfChange: Boolean) = checkVolumes()
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onServiceConnected() {
        super.onServiceConnected()
        teardown()
        instance = this
        prefs = Prefs(this)
        wm = getSystemService(WindowManager::class.java)
        am = getSystemService(AudioManager::class.java)
        nm = getSystemService(NotificationManager::class.java)
        ready = true

        for (s in STREAMS) lastVolume[s] = am.getStreamVolume(s)
        for (i in 0..4) fracs[i] = levelOf(i)

        val filter = IntentFilter().apply {
            addAction("android.media.VOLUME_CHANGED_ACTION")
            addAction(AudioManager.RINGER_MODE_CHANGED_ACTION)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(receiver, filter)
        }
        contentResolver.registerContentObserver(Settings.System.CONTENT_URI, true, observer)
        onPrefsChanged()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        teardown()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        teardown()
        super.onDestroy()
    }

    private fun teardown() {
        if (!ready) {
            if (instance === this) instance = null
            return
        }
        ready = false
        if (instance === this) instance = null
        handler.removeCallbacksAndMessages(null)
        removeEdge()
        removePanel()
        try { unregisterReceiver(receiver) } catch (e: Exception) {}
        try { contentResolver.unregisterContentObserver(observer) } catch (e: Exception) {}
    }

    /** Called by the settings screen whenever something changed. */
    fun onPrefsChanged() {
        if (!ready) return
        handler.removeCallbacks(hideLight)
        handler.removeCallbacks(hidePanel)
        removeEdge()
        removePanel()
        if (prefs.panelIdle) {
            val p = ensurePanel()
            p?.alpha = 0.3f
        }
    }

    /** Demo sweep so changes in settings can be seen right away. */
    fun preview() {
        if (!ready) return
        val t = currentTarget()
        showLight(t, 0.25f)
        showPanel()
        handler.postDelayed({ if (ready) showLight(t, 0.8f) }, 450)
    }

    // ------------------------------------------------------------------ key handling

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (!ready || !prefs.replacePanel) return false
        val code = event.keyCode
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) return false
        if (event.action == KeyEvent.ACTION_DOWN) {
            adjust(if (code == KeyEvent.KEYCODE_VOLUME_UP) 1 else -1)
        }
        return true
    }

    private fun enabledMask(): Int {
        val m = prefs.targetMask and 31
        return if (m == 0) 1 else m
    }

    private fun currentTarget(): Int {
        val mode = am.mode
        if (mode == AudioManager.MODE_IN_CALL || mode == AudioManager.MODE_IN_COMMUNICATION) return 3
        val t = prefs.target
        if (t in 0..4 && (enabledMask() shr t) and 1 == 1) return t
        for (i in 0..4) if ((enabledMask() shr i) and 1 == 1) return i
        return 0
    }

    private fun adjust(dir: Int) {
        val t = currentTarget()
        if (t == T_BRIGHT) {
            adjustBrightness(dir)
        } else {
            val s = STREAMS[t]
            var flags = 0
            if (t == 1) flags = AudioManager.FLAG_ALLOW_RINGER_MODES
            try {
                am.adjustStreamVolume(
                    s,
                    if (dir > 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                    flags
                )
            } catch (e: SecurityException) {
                toast("Allow Do Not Disturb access in Edge Volume Light settings")
            }
            lastVolume[s] = am.getStreamVolume(s)
            showLight(t, levelOf(t))
        }
        showPanel()
    }

    private fun adjustBrightness(dir: Int) {
        if (!Settings.System.canWrite(this)) {
            toast("Allow \"Modify system settings\" in Edge Volume Light settings")
            return
        }
        val cur = Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
        // work on a perceptual (square-root) scale so steps feel even
        val level = (sqrt(cur / 255f) + dir / 16f).coerceIn(0.05f, 1f)
        val b = (level * level * 255f).roundToInt().coerceIn(1, 255)
        try {
            Settings.System.putInt(
                contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
            )
            Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, b)
        } catch (e: Exception) {
            toast("Could not change brightness")
            return
        }
        showLight(T_BRIGHT, level)
    }

    private fun cycleTarget() {
        val mask = enabledMask()
        var t = currentTarget()
        for (k in 1..5) {
            val n = (t + k) % 5
            if ((mask shr n) and 1 == 1) {
                t = n
                break
            }
        }
        prefs.target = t
        showLight(t, levelOf(t))
        showPanel()
    }

    private fun cycleRinger() {
        val order = if (nm.isNotificationPolicyAccessGranted) {
            intArrayOf(
                AudioManager.RINGER_MODE_NORMAL,
                AudioManager.RINGER_MODE_VIBRATE,
                AudioManager.RINGER_MODE_SILENT
            )
        } else {
            intArrayOf(AudioManager.RINGER_MODE_NORMAL, AudioManager.RINGER_MODE_VIBRATE)
        }
        val i = order.indexOf(am.ringerMode)
        val next = order[(i + 1) % order.size]
        try {
            am.ringerMode = next
        } catch (e: SecurityException) {
            toast("Allow Do Not Disturb access in Edge Volume Light settings")
        }
        showPanel()
    }

    // ------------------------------------------------------------------ levels

    private fun levelOf(t: Int): Float {
        if (t == T_BRIGHT) {
            val b = Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
            return sqrt(b / 255f).coerceIn(0f, 1f)
        }
        val s = STREAMS[t]
        val min = am.getStreamMinVolume(s)
        val max = am.getStreamMaxVolume(s)
        return ((am.getStreamVolume(s) - min).toFloat() / (max - min).coerceAtLeast(1)).coerceIn(0f, 1f)
    }

    /** Catches volume changes that did not come from our key handler (headset buttons, apps...). */
    private fun checkVolumes() {
        if (!ready) return
        for ((i, s) in STREAMS.withIndex()) {
            val v = am.getStreamVolume(s)
            val old = lastVolume.put(s, v)
            if (old != null && old != v) {
                showLight(i, levelOf(i))
                return
            }
        }
    }

    // ------------------------------------------------------------------ edge light

    private fun createEdge(t: Int): EdgeView? {
        val d = resources.displayMetrics.density
        val v = EdgeView(this).also {
            it.side = prefs.side
            it.shape = prefs.shape
            it.colorMode = prefs.colorMode
            it.color = if (prefs.colorMode == 1) prefs.targetColor(t) else prefs.color
            it.color2 = prefs.color2
            it.thicknessPx = prefs.thickness * d
            it.glowPx = prefs.glow * d
            it.opacity = prefs.opacity / 100f
            it.effect = prefs.effect
            it.enterMode = prefs.enterAnim
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.layoutInDisplayCutoutMode =
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        return try {
            wm.addView(v, lp)
            edge = v
            if (prefs.effect == 1 || prefs.effect == 2) {
                phaseAnim = ValueAnimator.ofFloat(0f, 1f).apply {
                    duration = if (prefs.effect == 1) 1400L else 1100L
                    repeatCount = ValueAnimator.INFINITE
                    interpolator = LinearInterpolator()
                    addUpdateListener { v.phase = it.animatedValue as Float }
                    start()
                }
            }
            v
        } catch (e: Exception) {
            null
        }
    }

    private fun showLight(t: Int, f: Float) {
        if (!ready) return
        handler.removeCallbacks(hideLight)
        val existing = edge
        val v: EdgeView
        val first: Boolean
        if (existing == null) {
            v = createEdge(t) ?: return
            v.fraction = fracs[t]
            first = true
        } else {
            v = existing
            first = false
            if (prefs.colorMode == 1) v.updateColor(prefs.targetColor(t))
        }
        fracs[t] = f

        enterAnim?.cancel()
        if (prefs.enterAnim == 2) {
            v.enter = 1f
        } else {
            if (first) v.enter = 0f
            enterAnim = ValueAnimator.ofFloat(v.enter, 1f).apply {
                duration = 220
                addUpdateListener { v.enter = it.animatedValue as Float }
                start()
            }
        }

        fillAnim?.cancel()
        when (prefs.fillAnim) {
            0 -> v.fraction = f
            else -> {
                val bouncy = prefs.fillAnim == 2
                fillAnim = ValueAnimator.ofFloat(v.fraction, f).apply {
                    duration = if (bouncy) 380L else 160L
                    interpolator = if (bouncy) OvershootInterpolator(2.2f) else DecelerateInterpolator()
                    addUpdateListener { v.fraction = it.animatedValue as Float }
                    start()
                }
            }
        }

        if (prefs.effect == 3) {
            flashAnim?.cancel()
            flashAnim = ValueAnimator.ofFloat(1f, 0f).apply {
                duration = 300
                addUpdateListener { v.flash = it.animatedValue as Float }
                start()
            }
        }

        handler.postDelayed(hideLight, prefs.duration.toLong())
    }

    private fun hideEdge() {
        val v = edge ?: return
        if (prefs.enterAnim == 2) {
            removeEdge()
            return
        }
        enterAnim?.cancel()
        enterAnim = ValueAnimator.ofFloat(v.enter, 0f).apply {
            duration = 250
            addUpdateListener { v.enter = it.animatedValue as Float }
            addListener(object : AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(animation: Animator) {
                    cancelled = true
                }

                override fun onAnimationEnd(animation: Animator) {
                    if (!cancelled) removeEdge()
                }
            })
            start()
        }
    }

    private fun removeEdge() {
        phaseAnim?.cancel()
        fillAnim?.cancel()
        flashAnim?.cancel()
        enterAnim?.cancel()
        phaseAnim = null
        fillAnim = null
        flashAnim = null
        enterAnim = null
        edge?.let {
            try { wm.removeView(it) } catch (e: Exception) {}
        }
        edge = null
    }

    // ------------------------------------------------------------------ control panel

    private fun ensurePanel(): PanelView? {
        panel?.let { return it }
        val d = resources.displayMetrics.density
        val p = PanelView(
            this,
            prefs.color,
            { currentTarget() },
            { am.ringerMode },
            { cycleRinger() },
            { cycleTarget() }
        )
        val screenH = wm.currentWindowMetrics.bounds.height()
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or (if (prefs.side == 0) Gravity.START else Gravity.END)
        lp.x = (6 * d).toInt()
        lp.y = (screenH * prefs.panelY / 100f).toInt()
        return try {
            p.alpha = 0f
            wm.addView(p, lp)
            panel = p
            p
        } catch (e: Exception) {
            null
        }
    }

    private fun showPanel() {
        if (!ready) return
        handler.removeCallbacks(hidePanel)
        val p = ensurePanel() ?: return
        p.refresh()
        p.animate().cancel()
        p.animate().alpha(1f).setDuration(120).start()
        handler.postDelayed(hidePanel, prefs.panelDuration.toLong())
    }

    private fun hidePanelNow() {
        val p = panel ?: return
        p.animate().cancel()
        if (prefs.panelIdle) {
            p.animate().alpha(0.3f).setDuration(250).start()
        } else {
            p.animate().alpha(0f).setDuration(200).withEndAction { removePanel() }.start()
        }
    }

    private fun removePanel() {
        panel?.let {
            it.animate().cancel()
            try { wm.removeView(it) } catch (e: Exception) {}
        }
        panel = null
    }

    private fun toast(m: String) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
    }
}
