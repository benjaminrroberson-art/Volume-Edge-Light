package app.edgevolume

import android.accessibilityservice.AccessibilityService
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.Manifest
import android.app.KeyguardManager
import android.app.NotificationManager
import android.content.ComponentName
import android.content.pm.PackageManager
import android.media.audiofx.Visualizer
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.PowerManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.database.ContentObserver
import android.graphics.PixelFormat
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.animation.LinearInterpolator
import android.widget.Toast
import kotlin.math.*

/**
 * Accessibility service that
 *  - swallows the hardware volume keys (so the system panel never shows) and repeats while held,
 *  - adjusts the selected target (media / ring / alarm / call / brightness),
 *  - draws the edge light and a small gear control panel as accessibility overlays.
 */
class VolumeService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: VolumeService? = null

        val STREAMS = intArrayOf(
            AudioManager.STREAM_MUSIC,
            AudioManager.STREAM_RING,
            AudioManager.STREAM_ALARM,
            AudioManager.STREAM_VOICE_CALL
        )
        const val T_BRIGHT = 4
        val NAMES = arrayOf("Media", "Ring", "Alarm", "Call", "Brightness")

        @Volatile
        var musicStatus = "Music light: off"
    }

    private lateinit var prefs: Prefs
    private lateinit var wm: WindowManager
    private lateinit var am: AudioManager
    private lateinit var nm: NotificationManager
    private val handler = Handler(Looper.getMainLooper())
    private var ready = false

    private var edge: EdgeView? = null
    private var gear: GearView? = null
    private var card: MenuCard? = null
    private var gearTopPx = 0
    private var gearSizePx = 0
    private var scrim: View? = null
    private var scrimLp: WindowManager.LayoutParams? = null

    private val lastVolume = HashMap<Int, Int>()
    private val fracs = FloatArray(5)

    private var phaseAnim: ValueAnimator? = null
    private var enterAnim: ValueAnimator? = null
    private var flashAnim: ValueAnimator? = null

    // key hold state
    private var holdDir = 0
    private var holdStart = 0L

    private val hideLight = Runnable { hideEdge() }
    private val hidePanel = Runnable { hidePanelNow() }

    private val holdRunnable = object : Runnable {
        override fun run() {
            if (holdDir == 0 || !ready) return
            val held = SystemClock.uptimeMillis() - holdStart
            if (held > 25000L) {
                holdDir = 0
                return
            }
            adjust(holdDir)
            var iv = prefs.holdInterval.toFloat()
            if (prefs.holdAccel) iv /= (1f + (held / 1500f).coerceAtMost(2f))
            handler.postDelayed(this, iv.toLong().coerceAtLeast(25L))
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                "android.media.VOLUME_CHANGED_ACTION" -> checkVolumes()
                AudioManager.RINGER_MODE_CHANGED_ACTION -> card?.refresh()
            }
        }
    }

    private val observer = object : ContentObserver(handler) {
        override fun onChange(selfChange: Boolean) = checkVolumes()
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onServiceConnected() {
        super.onServiceConnected()
        teardown()
        instance = this
        prefs = Prefs(this)
        wm = getSystemService(WindowManager::class.java)
        am = getSystemService(AudioManager::class.java)
        nm = getSystemService(NotificationManager::class.java)
        ready = true

        for (s in STREAMS) lastVolume[s] = am.getStreamVolume(s)
        for (i in 0..4) fracs[i] = levelOf(i)

        val filter = IntentFilter().apply {
            addAction("android.media.VOLUME_CHANGED_ACTION")
            addAction(AudioManager.RINGER_MODE_CHANGED_ACTION)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(receiver, filter)
        }
        contentResolver.registerContentObserver(Settings.System.CONTENT_URI, true, observer)
        registerOutputWatcher()
        onPrefsChanged()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        teardown()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        teardown()
        super.onDestroy()
    }

    private fun teardown() {
        if (!ready) {
            if (instance === this) instance = null
            return
        }
        ready = false
        holdDir = 0
        if (instance === this) instance = null
        handler.removeCallbacksAndMessages(null)
        stopMusic(true)
        removeEdge()
        removePanel()
        unregisterOutputWatcher()
        try { unregisterReceiver(receiver) } catch (e: Exception) {}
        try { contentResolver.unregisterContentObserver(observer) } catch (e: Exception) {}
    }

    /** Called by the settings screen whenever something changed. */
    fun onPrefsChanged() {
        if (!ready) return
        handler.removeCallbacks(hideLight)
        handler.removeCallbacks(hidePanel)
        removeEdge()
        removePanel()
        resetMusic()
        if (prefs.panelIdle) {
            ensurePanel()?.alpha = gearAlpha(false)
        }
    }

    /** Demo sweep so changes in settings can be seen right away. */
    fun preview() {
        if (!ready) return
        val t = currentTarget()
        showLight(t, 0.2f)
        showPanel()
        handler.postDelayed({ if (ready) showLight(t, 0.85f) }, 500)
    }

    // ------------------------------------------------------------------ key handling

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (!ready || !prefs.replacePanel) return false
        val code = event.keyCode
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) return false
        val dir = if (code == KeyEvent.KEYCODE_VOLUME_UP) 1 else -1
        when (event.action) {
            KeyEvent.ACTION_DOWN -> if (event.repeatCount == 0) startHold(dir)
            KeyEvent.ACTION_UP -> stopHold(dir)
        }
        return true
    }

    private fun startHold(dir: Int) {
        adjust(dir)
        holdDir = dir
        holdStart = SystemClock.uptimeMillis()
        handler.removeCallbacks(holdRunnable)
        handler.postDelayed(holdRunnable, prefs.holdDelay.toLong())
    }

    private fun stopHold(dir: Int) {
        if (dir == holdDir) {
            holdDir = 0
            handler.removeCallbacks(holdRunnable)
        }
    }

    private fun enabledMask(): Int {
        val m = prefs.targetMask and 31
        return if (m == 0) 1 else m
    }

    private fun enabledTargets(): List<Int> =
        (0..4).filter { ((enabledMask() shr it) and 1) == 1 }

    private fun currentTarget(): Int {
        val mode = am.mode
        if (mode == AudioManager.MODE_IN_CALL || mode == AudioManager.MODE_IN_COMMUNICATION) return 3
        val t = prefs.target
        val list = enabledTargets()
        return if (t in list) t else list[0]
    }

    private fun adjust(dir: Int) {
        val t = currentTarget()
        if (t == T_BRIGHT) {
            adjustBrightness(dir)
        } else {
            val s = STREAMS[t]
            val flags = if (t == 1) AudioManager.FLAG_ALLOW_RINGER_MODES else 0
            try {
                am.adjustStreamVolume(
                    s,
                    if (dir > 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                    flags
                )
            } catch (e: SecurityException) {
                toast("Allow Do Not Disturb access in Edge Volume Light settings")
            }
            lastVolume[s] = am.getStreamVolume(s)
            showLight(t, levelOf(t))
        }
        showPanel()
    }

    private fun adjustBrightness(dir: Int) {
        if (!Settings.System.canWrite(this)) {
            toast("Allow \"Modify system settings\" in Edge Volume Light settings")
            holdDir = 0
            return
        }
        val cur = Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
        // work on a perceptual (square-root) scale so steps feel even
        val level = (sqrt(cur / 255f) + dir / 16f).coerceIn(0.05f, 1f)
        val b = (level * level * 255f).roundToInt().coerceIn(1, 255)
        try {
            Settings.System.putInt(
                contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
            )
            Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, b)
        } catch (e: Exception) {
            toast("Could not change brightness")
            holdDir = 0
            return
        }
        showLight(T_BRIGHT, level)
    }

    private fun selectTarget(t: Int) {
        prefs.target = t
        showLight(t, levelOf(t))
        showPanel()
    }

    private fun setRinger(mode: Int) {
        try {
            am.ringerMode = mode
        } catch (e: SecurityException) {
            toast("Allow Do Not Disturb access in Edge Volume Light settings")
        }
        showPanel()
    }

    // ------------------------------------------------------------------ levels

    private fun levelOf(t: Int): Float {
        if (t == T_BRIGHT) {
            val b = Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
            return sqrt(b / 255f).coerceIn(0f, 1f)
        }
        val s = STREAMS[t]
        val min = am.getStreamMinVolume(s)
        val max = am.getStreamMaxVolume(s)
        return ((am.getStreamVolume(s) - min).toFloat() / (max - min).coerceAtLeast(1)).coerceIn(0f, 1f)
    }

    /** Catches volume changes that did not come from our key handler (headset buttons, apps...). */
    private fun checkVolumes() {
        if (!ready) return
        for ((i, s) in STREAMS.withIndex()) {
            val v = am.getStreamVolume(s)
            val old = lastVolume.put(s, v)
            if (old != null && old != v) {
                showLight(i, levelOf(i))
                return
            }
        }
    }

    // ------------------------------------------------------------------ edge light

    private fun createEdge(t: Int): EdgeView? {
        val d = resources.displayMetrics.density
        val v = EdgeView(this).also {
            it.side = prefs.side
            it.shape = prefs.shape
            it.pattern = prefs.pattern
            it.colorMode = prefs.colorMode
            it.color = if (prefs.colorMode == 1) prefs.targetColor(t) else prefs.color
            it.color2 = prefs.color2
            it.thicknessPx = prefs.thickness * d
            it.glowPx = prefs.glow * d
            it.cornerPx = prefs.corner * d
            it.opacity = prefs.opacity / 100f
            it.effect = prefs.effect
            it.fx = prefs.effectIntensity / 100f
            it.enterMode = prefs.enterAnim
            it.motion = if (prefs.enterAnim == 3 && prefs.fillAnim == 0) 1 else prefs.fillAnim
            it.smoothMs = prefs.smoothMs
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.layoutInDisplayCutoutMode =
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        return try {
            wm.addView(v, lp)
            edge = v
            if (prefs.effect in intArrayOf(1, 2, 4, 5, 6, 7)) {
                val base = when (prefs.effect) {
                    1 -> 1400f
                    2 -> 1100f
                    4 -> 2000f
                    5 -> 1200f
                    6 -> 1800f
                    else -> 4000f
                }
                phaseAnim = ValueAnimator.ofFloat(0f, 1f).apply {
                    duration = (base / (prefs.effectSpeed / 100f).coerceAtLeast(0.2f)).toLong()
                    repeatCount = ValueAnimator.INFINITE
                    interpolator = LinearInterpolator()
                    addUpdateListener { v.phase = it.animatedValue as Float }
                    start()
                }
            }
            v
        } catch (e: Exception) {
            null
        }
    }

    private fun showLight(t: Int, f: Float) {
        if (!ready) return
        if (t == 0) {
            val mv = musicView
            if (mv != null) {
                fracs[0] = f
                musicLevel = f
                mv.moveTo(musicShown(f))
                return
            }
        }
        handler.removeCallbacks(hideLight)
        val existing = edge
        val v: EdgeView
        val first: Boolean
        if (existing == null) {
            v = createEdge(t) ?: return
            v.snapTo(if (prefs.enterAnim == 3) 0f else fracs[t])
            first = true
        } else {
            v = existing
            first = false
            if (prefs.colorMode == 1) v.updateColor(prefs.targetColor(t))
        }
        fracs[t] = f

        enterAnim?.cancel()
        if (prefs.enterAnim == 2 || prefs.enterAnim == 3) {
            v.enter = 1f
        } else {
            if (first) v.enter = 0f
            enterAnim = ValueAnimator.ofFloat(v.enter, 1f).apply {
                duration = 220
                addUpdateListener { v.enter = it.animatedValue as Float }
                start()
            }
        }

        v.moveTo(f)

        if (prefs.effect == 3) {
            flashAnim?.cancel()
            flashAnim = ValueAnimator.ofFloat(1f, 0f).apply {
                duration = 300
                addUpdateListener { v.flash = it.animatedValue as Float }
                start()
            }
        }

        handler.postDelayed(hideLight, prefs.duration.toLong())
    }

    private fun hideEdge() {
        val v = edge ?: return
        if (prefs.enterAnim == 2) {
            removeEdge()
            return
        }
        val grow = prefs.enterAnim == 3
        if (grow) v.moveTo(0f)
        enterAnim?.cancel()
        enterAnim = ValueAnimator.ofFloat(v.enter, 0f).apply {
            duration = if (grow) (prefs.smoothMs * 1.1f).toLong().coerceIn(300L, 1000L) else 250L
            addUpdateListener { v.enter = it.animatedValue as Float }
            addListener(object : AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(animation: Animator) {
                    cancelled = true
                }

                override fun onAnimationEnd(animation: Animator) {
                    if (!cancelled) removeEdge()
                }
            })
            start()
        }
    }

    private fun removeEdge() {
        phaseAnim?.cancel()
        flashAnim?.cancel()
        enterAnim?.cancel()
        phaseAnim = null
        flashAnim = null
        enterAnim = null
        edge?.let {
            try { wm.removeView(it) } catch (e: Exception) {}
        }
        edge = null
    }

    // ------------------------------------------------------------------ audio output animation

    private var connectView: ConnectView? = null
    private var connectAnim: ValueAnimator? = null
    private var watchStart = 0L
    private var lastConnectAt = 0L

    private val outputCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(added: Array<out AudioDeviceInfo>) = outputEvent(added, true)
        override fun onAudioDevicesRemoved(removed: Array<out AudioDeviceInfo>) = outputEvent(removed, false)
    }
    private var watching = false

    private fun registerOutputWatcher() {
        if (watching) return
        watchStart = SystemClock.elapsedRealtime()
        try {
            am.registerAudioDeviceCallback(outputCallback, handler)
            watching = true
        } catch (e: Exception) {
        }
    }

    private fun unregisterOutputWatcher() {
        if (watching) {
            try { am.unregisterAudioDeviceCallback(outputCallback) } catch (e: Exception) {}
            watching = false
        }
        removeConnect()
    }

    private fun isBt(t: Int) = t == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
        t == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
        t == AudioDeviceInfo.TYPE_HEARING_AID ||
        (Build.VERSION.SDK_INT >= 31 && t == AudioDeviceInfo.TYPE_BLE_HEADSET)

    private fun isWired(t: Int) = t == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
        t == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
        t == AudioDeviceInfo.TYPE_USB_HEADSET ||
        t == AudioDeviceInfo.TYPE_USB_DEVICE

    private fun outputEvent(devs: Array<out AudioDeviceInfo>, connected: Boolean) {
        if (!ready || !prefs.connectOn) return
        val now = SystemClock.elapsedRealtime()
        if (now - watchStart < 1500) return                 // initial burst of existing devices
        if (!connected && !prefs.connectDisc) return
        val match = devs.any {
            it.isSink && ((prefs.connectBt && isBt(it.type)) || (prefs.connectWired && isWired(it.type)))
        }
        if (!match) return
        if (now - lastConnectAt < 1500) return             // phones report A2DP + SCO together
        lastConnectAt = now
        showConnect(connected)
    }

    fun previewConnect(connected: Boolean) {
        if (!ready) return
        showConnect(connected)
    }

    private fun showConnect(connected: Boolean) {
        removeConnect()
        val d = resources.displayMetrics.density
        val v = ConnectView(this).also {
            it.style = prefs.connectStyle
            it.side = prefs.side
            it.down = connected
            it.thickPx = prefs.connectThick * d
            it.glowPx = prefs.connectGlow * d
            it.strength = prefs.connectBright / 100f
            if (prefs.connectColorMode == 0) {
                it.c1 = prefs.color
                it.c2 = prefs.color2
            } else {
                it.c1 = if (connected) prefs.connectColor else prefs.connectColorOff
                it.c2 = it.c1
            }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.layoutInDisplayCutoutMode =
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        try {
            wm.addView(v, lp)
        } catch (e: Exception) {
            return
        }
        connectView = v
        connectAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = prefs.connectDuration.toLong().coerceIn(300, 5000)
            interpolator = LinearInterpolator()
            addUpdateListener { v.t = it.animatedValue as Float }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) {
                    if (connectView === v) removeConnect()
                }
            })
            start()
        }
    }

    private fun removeConnect() {
        connectAnim?.removeAllListeners()
        connectAnim?.cancel()
        connectAnim = null
        connectView?.let {
            try { wm.removeView(it) } catch (e: Exception) {}
        }
        connectView = null
    }

    // ------------------------------------------------------------------ gear button + menu card
    // The gear and the menu card are separate, fixed-size windows. Nothing is ever resized or
    // moved, because the system animates window resizes (which made the gear fly around).

    private fun gearStyle(): GearStyle {
        val d = resources.displayMetrics.density
        val accent = if (prefs.gearColorMode == 1) prefs.gearColor else prefs.color
        return GearStyle(
            prefs.gearIcon, (prefs.gearSize * d).toInt(), prefs.gearOpacity / 100f,
            prefs.gearBgStyle, prefs.gearBgColor, prefs.gearShape, accent, prefs.side != 0
        )
    }

    private fun gearAlpha(active: Boolean): Float =
        prefs.gearOpacity / 100f * (if (active) 1f else prefs.gearIdle / 100f)

    private fun ensurePanel(): GearView? {
        gear?.let { return it }
        ensureScrim()
        val d = resources.displayMetrics.density
        val st = gearStyle()
        val g = GearView(this, st)
        g.setOnClickListener {
            toggleCard()
            showPanel()
        }
        val screenH = wm.currentWindowMetrics.bounds.height()
        val lp = WindowManager.LayoutParams(
            st.sizePx,
            st.sizePx,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or (if (prefs.side == 0) Gravity.START else Gravity.END)
        lp.x = (prefs.gearInset * d).toInt()
        lp.y = (screenH * prefs.panelY / 100f).toInt()
        gearTopPx = lp.y
        gearSizePx = st.sizePx
        return try {
            g.alpha = 0f
            wm.addView(g, lp)
            gear = g
            g
        } catch (e: Exception) {
            null
        }
    }

    private fun toggleCard() {
        if (card != null) closeCard() else openCard()
    }

    private fun openCard() {
        if (card != null) return
        val d = resources.displayMetrics.density
        val c = MenuCard(
            this,
            gearStyle(),
            { currentTarget() },
            { am.ringerMode },
            { enabledTargets() },
            { nm.isNotificationPolicyAccessGranted },
            { mode -> setRinger(mode) },
            { t -> selectTarget(t) },
            { showPanel() }
        )
        c.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val w = c.measuredWidth
        val h = c.measuredHeight
        val screenH = wm.currentWindowMetrics.bounds.height()
        val gap = (6 * d).toInt()
        var below = true
        var y = gearTopPx + gearSizePx + gap
        if (y + h > screenH - (24 * d).toInt()) {
            below = false
            y = gearTopPx - gap - h
        }
        if (y < 0) y = 0
        val lp = WindowManager.LayoutParams(
            w,
            h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or (if (prefs.side == 0) Gravity.START else Gravity.END)
        lp.x = (prefs.gearInset * d).toInt()
        lp.y = y
        try {
            c.alpha = 0f
            c.translationY = (if (below) -8 else 8) * d
            wm.addView(c, lp)
            card = c
            c.animate().alpha(1f).translationY(0f).setDuration(170).start()
            setScrimTouchable(prefs.closeOutside)
        } catch (e: Exception) {
        }
    }

    private fun closeCard() {
        val c = card ?: return
        card = null
        setScrimTouchable(false)
        c.animate().cancel()
        c.animate().alpha(0f).setDuration(120).withEndAction {
            try { wm.removeView(c) } catch (e: Exception) {}
        }.start()
    }

    private fun showPanel() {
        if (!ready) return
        handler.removeCallbacks(hidePanel)
        val g = ensurePanel() ?: return
        card?.refresh()
        g.animate().cancel()
        g.animate().alpha(gearAlpha(true)).setDuration(120).start()
        if (card != null) {
            if (!prefs.panelOpenForever) handler.postDelayed(hidePanel, prefs.panelOpenDuration.toLong())
        } else {
            handler.postDelayed(hidePanel, prefs.panelDuration.toLong())
        }
    }

    private fun hidePanelNow() {
        closeCard()
        val g = gear ?: return
        g.animate().cancel()
        if (prefs.panelIdle) {
            g.animate().alpha(gearAlpha(false)).setDuration(250).start()
        } else {
            g.animate().alpha(0f).setDuration(200).withEndAction { removePanel() }.start()
        }
    }

    private fun removePanel() {
        card?.let {
            it.animate().cancel()
            try { wm.removeView(it) } catch (e: Exception) {}
        }
        card = null
        gear?.let {
            it.animate().cancel()
            try { wm.removeView(it) } catch (e: Exception) {}
        }
        gear = null
        scrim?.let {
            try { wm.removeView(it) } catch (e: Exception) {}
        }
        scrim = null
        scrimLp = null
    }

    /**
     * Invisible full-screen window sitting just under the gear. It only catches touches
     * while the menu is open, so a tap anywhere else closes the menu.
     */
    private fun ensureScrim() {
        if (scrim != null) return
        val v = View(this)
        v.setOnTouchListener { _, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) closeMenu()
            true
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        try {
            wm.addView(v, lp)
            scrim = v
            scrimLp = lp
        } catch (e: Exception) {
        }
    }

    private fun setScrimTouchable(on: Boolean) {
        val v = scrim ?: return
        val lp = scrimLp ?: return
        lp.flags = if (on) {
            lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        try { wm.updateViewLayout(v, lp) } catch (e: Exception) {}
    }

    private fun closeMenu() {
        handler.removeCallbacks(hidePanel)
        hidePanelNow()
    }

    // ------------------------------------------------------------------ music reaction
    // A second, persistent edge window that sits at the media volume level and sticks out
    // with the music. Audio is only analysed (FFT), never recorded or stored.

    private var musicView: EdgeView? = null
    private var musicAnim: ValueAnimator? = null
    private var viz: Visualizer? = null
    private var musicRetryAt = 0L
    private var musicDemoUntil = 0L
    private var musicSince = 0L
    private var musicHeard = 0L
    private var musicLevel = 0f
    private var peak = 6f
    private var bassSlow = 0f
    private var lastBeat = 0L
    private val raw = FloatArray(48)
    private val bands = FloatArray(48)

    private val musicPoll = object : Runnable {
        override fun run() {
            if (!ready) return
            try {
                musicTick()
            } catch (e: Exception) {
                musicStatus = "Music light: error (" + e.javaClass.simpleName + ")"
            }
            handler.postDelayed(this, 1000)
        }
    }

    private val demoRunnable = object : Runnable {
        override fun run() {
            val v = musicView ?: return
            if (!ready || SystemClock.uptimeMillis() > musicDemoUntil) return
            val t = SystemClock.uptimeMillis() / 1000f
            for (i in 0 until 48) {
                val a = 0.5f + 0.5f * sin(t * (2.0f + i * 0.31f) + i)
                val env = 0.55f + 0.45f * sin(t * 1.3f)
                bands[i] = (a * env * (1f - i / 70f)).coerceIn(0f, 1f)
            }
            v.feed(bands, 48)
            val now = SystemClock.uptimeMillis()
            if (now - lastBeat > 520) {
                lastBeat = now
                v.beat(0.9f)
            }
            handler.postDelayed(this, 33)
        }
    }

    private fun musicShown(f: Float): Float =
        if (SystemClock.uptimeMillis() < musicDemoUntil && f < 0.15f) 0.6f else f

    private fun resetMusic() {
        stopMusic(true)
        musicRetryAt = 0L
        handler.removeCallbacks(musicPoll)
        handler.post(musicPoll)
    }

    /** "Test music light" button: 8 seconds of synthetic music so styles can be tuned. */
    fun previewMusic() {
        if (!ready) return
        musicDemoUntil = SystemClock.uptimeMillis() + 8000
        stopMusic(true)
        handler.removeCallbacks(musicPoll)
        handler.post(musicPoll)
    }

    private fun musicTick() {
        val now = SystemClock.uptimeMillis()
        val demo = now < musicDemoUntil
        var why = ""
        var want = demo
        if (!demo) {
            want = false
            when {
                !prefs.musicEnabled -> why = "off"
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED ->
                    why = "needs the audio permission"
                !getSystemService(PowerManager::class.java).isInteractive -> why = "screen off"
                !prefs.musicLock && getSystemService(KeyguardManager::class.java).isKeyguardLocked ->
                    why = "locked"
                now < musicRetryAt && musicView == null -> why = musicStatus.removePrefix("Music light: ")
                !isAllowedMusicPlaying() -> why = "waiting for music"
                else -> want = true
            }
        }
        if (want && musicView == null) startMusic(demo)
        else if (!want && musicView != null) stopMusic(false)
        if (musicView != null) {
            musicStatus = when {
                demo -> "Music light: demo"
                now - musicSince > 4000 && now - musicHeard > 4000 ->
                    "Music light: connected but the audio is silent (capture may be blocked on this phone)"
                else -> "Music light: active"
            }
        } else if (!demo && why.isNotEmpty() && now >= musicRetryAt) {
            musicStatus = "Music light: $why"
        }
    }

    private fun isAllowedMusicPlaying(): Boolean {
        if (prefs.musicAppMode == 0) return am.isMusicActive
        val picked = prefs.musicApps.split(',').filter { it.isNotEmpty() }.toSet()
        val sessions = try {
            getSystemService(MediaSessionManager::class.java)
                .getActiveSessions(ComponentName(this, MediaListener::class.java))
        } catch (e: SecurityException) {
            musicStatus = "Music light: needs notification access (to see which app plays)"
            return prefs.musicAppMode == 2 && am.isMusicActive
        }
        for (sess in sessions) {
            if (sess.playbackState?.state != PlaybackState.STATE_PLAYING) continue
            val inSet = sess.packageName in picked
            if (prefs.musicAppMode == 1 && inSet) return true
            if (prefs.musicAppMode == 2 && !inSet) return true
        }
        return false
    }

    private fun startMusic(demo: Boolean) {
        val now = SystemClock.uptimeMillis()
        if (!demo) {
            try {
                startCapture()
            } catch (e: Throwable) {
                stopCapture()
                musicRetryAt = now + 30000
                musicStatus = "Music light: couldn't start audio capture (" + e.javaClass.simpleName + ")"
                return
            }
        }
        val d = resources.displayMetrics.density
        val t = 0
        val v = EdgeView(this).also {
            it.side = prefs.side
            it.shape = EdgeView.BAR
            it.pattern = if (prefs.pattern == 1) 1 else 0
            it.colorMode = prefs.colorMode
            it.color = if (prefs.colorMode == 1) prefs.targetColor(t) else prefs.color
            it.color2 = prefs.color2
            it.thicknessPx = prefs.thickness * d
            it.glowPx = prefs.glow * d
            it.cornerPx = prefs.corner * d
            it.opacity = prefs.musicOpacity / 100f
            it.effect = 0
            it.vizStyle = prefs.musicStyle + 1
            it.vizBars = prefs.musicBars
            it.vizDepthPx = prefs.musicDepth * d
            it.motion = 1
            it.smoothMs = prefs.smoothMs
            it.enter = 0f
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.layoutInDisplayCutoutMode =
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        try {
            wm.addView(v, lp)
        } catch (e: Exception) {
            stopCapture()
            return
        }
        musicView = v
        musicSince = now
        musicHeard = now
        peak = 6f
        bassSlow = 0f
        musicLevel = levelOf(0)
        v.snapTo(musicShown(musicLevel))
        musicAnim?.cancel()
        musicAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 400
            addUpdateListener { v.enter = it.animatedValue as Float }
            start()
        }
        if (demo) handler.post(demoRunnable)
    }

    private fun stopMusic(immediate: Boolean) {
        handler.removeCallbacks(demoRunnable)
        stopCapture()
        musicAnim?.cancel()
        musicAnim = null
        val v = musicView ?: return
        musicView = null
        if (immediate) {
            try { wm.removeView(v) } catch (e: Exception) {}
            return
        }
        musicAnim = ValueAnimator.ofFloat(v.enter, 0f).apply {
            duration = 450
            addUpdateListener { v.enter = it.animatedValue as Float }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    try { wm.removeView(v) } catch (e: Exception) {}
                }
            })
            start()
        }
    }

    private fun startCapture() {
        val vis = Visualizer(0)
        viz = vis
        vis.setEnabled(false)
        vis.setCaptureSize(Visualizer.getCaptureSizeRange()[1])
        vis.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
            override fun onWaveFormDataCapture(v: Visualizer?, w: ByteArray?, sr: Int) {}
            override fun onFftDataCapture(v: Visualizer?, f: ByteArray?, sr: Int) {
                if (f == null) return
                val copy = f.clone()
                handler.post { onFft(copy) }
            }
        }, min(Visualizer.getMaxCaptureRate(), 30000), false, true)
        vis.setEnabled(true)
    }

    private fun stopCapture() {
        val vis = viz ?: return
        viz = null
        try { vis.setEnabled(false) } catch (e: Exception) {}
        try { vis.release() } catch (e: Exception) {}
    }

    private fun onFft(fft: ByteArray) {
        val v = musicView ?: return
        val n = prefs.musicBars.coerceIn(4, 48)
        val bins = fft.size / 2
        if (bins < 16) return
        val hiBin = (bins * 0.75f).coerceAtLeast(n + 2f)
        val lnHi = ln(hiBin)
        var maxv = 0f
        for (i in 0 until n) {
            val a = exp(lnHi * i / n)
            val b = exp(lnHi * (i + 1) / n)
            val s = a.toInt().coerceAtLeast(1)
            val e = max(b.toInt(), s + 1).coerceAtMost(bins - 1)
            var sum = 0f
            var cnt = 0
            for (k in s until e) {
                val re = fft[2 * k].toFloat()
                val im = fft[2 * k + 1].toFloat()
                sum += sqrt(re * re + im * im)
                cnt++
            }
            val avg = if (cnt > 0) sum / cnt else 0f
            raw[i] = avg * (1f + 1.5f * i / n)
            if (raw[i] > maxv) maxv = raw[i]
        }
        val now = SystemClock.uptimeMillis()
        if (maxv > 1f) musicHeard = now
        peak = max(max(maxv, peak * 0.992f), 6f)
        val gain = prefs.musicSens / 100f
        for (i in 0 until n) {
            bands[i] = ((raw[i] / peak).pow(0.85f) * gain).coerceIn(0f, 1.2f)
        }
        v.feed(bands, n)
        var bass = 0f
        val bc = min(3, n)
        for (i in 0 until bc) bass += bands[i]
        bass /= bc
        if (bass > bassSlow * 1.35f + 0.08f && now - lastBeat > 200) {
            lastBeat = now
            v.beat(bass)
        }
        bassSlow = bassSlow * 0.9f + bass * 0.1f
    }

    private fun toast(m: String) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
    }
}
