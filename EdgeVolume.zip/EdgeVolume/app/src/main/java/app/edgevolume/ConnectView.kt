package app.edgevolume

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Shader
import android.view.View
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Short one-shot animation shown when an audio output connects or disconnects. */
class ConnectView(ctx: Context) : View(ctx) {
    var t = 0f
        set(v) {
            field = v
            invalidate()
        }

    /** 0 sweep, 1 pulse, 2 flash, 3 comet */
    var style = 0
    var side = 1            // 0 left, 1 right, 2 both
    var c1 = Color.CYAN
    var c2 = Color.MAGENTA
    var thickPx = 8f
    var glowPx = 40f
    var strength = 1f
    var down = true         // direction of travel (connect = down, disconnect = up)

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val maskPaint = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        if (side == 0 || side == 2) drawSide(canvas, w, h, true)
        if (side == 1 || side == 2) drawSide(canvas, w, h, false)
    }

    private fun a(c: Int, f: Float): Int =
        Color.argb((Color.alpha(c) * f.coerceIn(0f, 1f)).toInt(), Color.red(c), Color.green(c), Color.blue(c))

    private fun drawSide(canvas: Canvas, w: Float, h: Float, left: Boolean) {
        val gw = thickPx + glowPx
        val x0 = if (left) 0f else w - gw
        val x1 = if (left) gw else w
        val frac = (thickPx / gw).coerceIn(0.05f, 0.95f)

        // overall alpha envelope + vertical mask
        var env = 1f
        val tail = h * 0.45f
        var mStart = 0f
        var mEnd = h
        var soft = true
        when (style) {
            0 -> { // sweep: fills along the edge then fades
                val head = min(1f, t / 0.55f) * h
                env = if (t < 0.55f) 1f else 1f - (t - 0.55f) / 0.45f
                if (down) { mStart = 0f; mEnd = head } else { mStart = h - head; mEnd = h }
            }
            1 -> env = sin(Math.PI.toFloat() * t)           // pulse: breathe in and out
            2 -> { val k = 1f - t; env = k * k * (if (t < 0.06f) t / 0.06f else 1f) } // flash
            else -> { // comet: a bright head with a fading tail travels along the edge
                val hp = t * (h + tail)
                if (down) { mStart = hp - tail; mEnd = hp } else { mStart = h - hp; mEnd = h - hp + tail }
                soft = false
            }
        }
        env = (env * strength).coerceIn(0f, 1f)
        if (env <= 0.004f) return
        if (mEnd - mStart < 1f) return

        val save = canvas.saveLayerAlpha(x0, 0f, x1, h, (env * 255).toInt())
        // horizontal glow: bright at the screen edge, fading inward
        val first = c1
        val colors = intArrayOf(a(first, 1f), a(first, 0.85f), a(first, 0f))
        val pos = floatArrayOf(0f, frac, 1f)
        paint.shader = if (left)
            LinearGradient(x0, 0f, x1, 0f, colors, pos, Shader.TileMode.CLAMP)
        else
            LinearGradient(x1, 0f, x0, 0f, colors, pos, Shader.TileMode.CLAMP)
        canvas.drawRect(x0, 0f, x1, h, paint)
        paint.shader = null

        // second colour mixed in along the length
        val tint = LinearGradient(0f, 0f, 0f, h, intArrayOf(a(c2, 0f), a(c2, 0.55f), a(c2, 0f)),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        paint.shader = tint
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP)
        canvas.drawRect(x0, 0f, x1, h, paint)
        paint.xfermode = null
        paint.shader = null

        // vertical mask
        val len = mEnd - mStart
        val m = if (style == 0) {
            val s = min(0.3f, 140f / max(len, 1f))
            if (down) LinearGradient(0f, mStart, 0f, mEnd, intArrayOf(Color.WHITE, Color.WHITE, 0),
                floatArrayOf(0f, 1f - s, 1f), Shader.TileMode.CLAMP)
            else LinearGradient(0f, mStart, 0f, mEnd, intArrayOf(0, Color.WHITE, Color.WHITE),
                floatArrayOf(0f, s, 1f), Shader.TileMode.CLAMP)
        } else if (!soft) {
            if (down) LinearGradient(0f, mStart, 0f, mEnd, intArrayOf(0, Color.WHITE),
                floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
            else LinearGradient(0f, mStart, 0f, mEnd, intArrayOf(Color.WHITE, 0),
                floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
        } else null
        maskPaint.alpha = 255
        if (m != null) {
            maskPaint.shader = m
            // clip everything outside the lit range
            val top = max(0f, mStart)
            val bot = min(h, mEnd)
            // draw mask only inside [top, bot]; clear the rest
            canvas.save()
            canvas.clipRect(x0, 0f, x1, top)
            canvas.drawColor(0, PorterDuff.Mode.CLEAR)
            canvas.restore()
            canvas.save()
            canvas.clipRect(x0, bot, x1, h)
            canvas.drawColor(0, PorterDuff.Mode.CLEAR)
            canvas.restore()
            canvas.drawRect(x0, top, x1, bot, maskPaint)
            maskPaint.shader = null
        }
        canvas.restoreToCount(save)
    }
}
