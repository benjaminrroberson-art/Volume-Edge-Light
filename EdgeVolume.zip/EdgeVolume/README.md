# Edge Volume Light 2.0
Replaces the system volume panel with a glowing edge light, plus a small control panel (ringer mode + which volume the keys control, including brightness).
No Google services, no network, no dependencies.

## Build
- Android Studio: File > Open this folder > Build > Build APK(s)
- Or GitHub: push to a repo, run the "Build APK" action, download app-debug.apk from the run's artifacts.

## Install on GrapheneOS
1. Open the APK from Files (allow "install unknown apps" for Files when prompted).
2. Open the app > Accessibility service > turn on "Edge Volume Light".
   If the toggle is greyed out: Settings > Apps > Edge Volume Light > ⋮ > Allow restricted settings, then try again.
3. Optional: grant "Modify system settings" (brightness) and "Do Not Disturb access" (silent mode) from the setup rows.
4. Settings > Apps > Edge Volume Light > Battery > Unrestricted.
5. Press a volume key, or tap Test.

## Known limits
- Power + Volume Down screenshot shortcut does not work while "Replace system volume panel" is on (turn it off to get it back).
- Pressing volume up at max (or down at min) shows no change, because nothing changed.
