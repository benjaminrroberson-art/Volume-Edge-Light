# Edge Volume Light 2.1
Replaces the system volume panel with a glowing edge light and a small gear button (ringer mode + what the volume keys control, including brightness).
No Google services, no network, no dependencies.

Build: push EdgeVolume.zip + .github/workflows/build.yml to a GitHub repo. Add secrets KEYSTORE_B64 and KEYSTORE_PASS so every build is signed with the same key (updates then install over the top, e.g. via Obtainium).

Install: enable the accessibility service from the app. If greyed out: App info > menu > Allow restricted settings.
Known limit: power + volume-down screenshot shortcut is blocked while "Replace system volume panel" is on.
